<?php

//Initialize the update checker.
require 'theme-updates/theme-update-checker.php';
$example_update_checker = new ThemeUpdateChecker(
	'example-theme',                                            //Theme folder name, AKA "slug". 
	'http://w-shadow.com/files/example-theme-updates/info.json' //URL of the metadata file.
);