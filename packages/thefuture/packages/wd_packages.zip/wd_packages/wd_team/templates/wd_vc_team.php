<?php
# Visual Composer installed?
if (function_exists('visual_composer')) {
	if (!function_exists('wd_team_vc_shortcodes')) {
		/**
		 * Add theme's custom shortcodes to Visual Composer
		 */
		function wd_team_vc_shortcodes() {
			/****************************************************************************/
			/*							Team Member 									*/
			/****************************************************************************/
			$team_member_array 	= tvlgiao_wpdance_vc_get_data_by_post_type('team');
			$team_category 		= tvlgiao_wpdance_vc_get_list_category('team_categories');

			# Add shortcode Site Header
			vc_map(array(
				'name' 				=> esc_html__("WD - Team Memmber", 'wd_package'),
				'base' 				=> 'wd_team_member',
				'description' 		=> esc_html__("Display Info Team Member", 'wd_package'),
				'category' 			=> esc_html__("WPDance Shortcode", 'wd_package'),
				'icon'        		=> 'icon-wpb-ninjaforms',
				'params' => array(
					array(
						'type' 				=> 'dropdown',
						'heading' 			=> esc_html__( 'Type', 'wd_package' ),
						'param_name' 		=> 'type',
						'admin_label' 		=> true,
						'value' => array(
								'Single Member'		=> 'single',
								'Multi Member'		=> 'multi'
								
							),
						'description' 		=> ''
					),
					//Single Setting
					array(
						'type' 				=> 'dropdown',
						'heading' 			=> esc_html__('Select Team', 'wd_package' ),
						'param_name' 		=> 'id_team',
						'admin_label' 		=> true,
						'value' 			=> $team_member_array,
						'description' 		=> '',
						'dependency'		=> Array('element' => "type", 'value' => array('single'))
					),
					//Multi Setting
					array(
						'type' 			=> 'dropdown',
						'heading' 		=> esc_html__( 'Select Category', 'wd_package' ),
						'param_name' 	=> 'id_category',
						'admin_label' 	=> true,
						'value' 		=> $team_category,
						'description' 	=> '',
						'dependency'	=> Array('element' => "type", 'value' => array('multi'))
					),
					array(
						'type' 			=> 'dropdown',
						'heading' 		=> esc_html__( 'Columns', 'wd_package' ),
						'param_name' 	=> 'columns',
						'admin_label' 	=> true,
						'value' 		=> tvlgiao_wpdance_vc_get_list_tvgiao_columns(),
						'description' 	=> '',
						'std'			=> '4',
						'edit_field_class' => 'vc_col-sm-6',
						'dependency'	=> Array('element' => "type", 'value' => array('multi'))
					),
					array(
						'type' 				=> 'dropdown',
						'heading' 			=> esc_html__( 'Columns On Tablet', 'wd_package' ),
						'param_name' 		=> 'columns_tablet',
						'admin_label' 		=> true,
						'value' 			=> tvlgiao_wpdance_vc_get_list_columns_tablet(),
						'std'				=> 2,
						'description' 		=> esc_html__( '', 'wd_package' ),
						"group"				=> esc_html__('Responsive', 'wd_package'),
					),
					array(
						'type' 				=> 'dropdown',
						'heading' 			=> esc_html__( 'Columns On Mobile', 'wd_package' ),
						'param_name' 		=> 'columns_mobile',
						'admin_label' 		=> true,
						'value' 			=> tvlgiao_wpdance_vc_get_list_columns_mobile(),
						'std'				=> 1,
						'description' 		=> esc_html__( '', 'wd_package' ),
						"group"				=> esc_html__('Responsive', 'wd_package'),
					),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> esc_html__("Number Teammember", 'wd_package'),
						'description'	=> esc_html__("", 'wd_package'),
						'admin_label' 	=> true,
						'param_name' 	=> 'number_teammember',
						'value' 		=> '8',
						'edit_field_class' => 'vc_col-sm-6',
						'dependency'	=> Array('element' => "type", 'value' => array('multi'))
					),
					//Slider
					array(
						"type" 			=> "dropdown",
						"class" 		=> "",
						"heading" 		=> esc_html__("Is Slider", 'wd_package'),
						"admin_label" 	=> true,
						"param_name" 	=> "is_slider",
						"value" 		=> array(
								'Yes' 		=> '1',
								'No' 		=> '0'
							),
						"description" 	=> "",
						'dependency'	=> Array('element' => "type", 'value' => array('multi'))
					),
					array(
						"type" 			=> "dropdown",
						"class" 		=> "",
						"heading" 		=> esc_html__("Slider Type", 'wd_package'),
						"admin_label" 	=> true,
						"param_name" 	=> "slider_type",
						"value" 		=> tvlgiao_wpdance_vc_get_list_slider_type(),
						"description" 	=> "",
						"std"			=> 'owl',
						'edit_field_class' => 'vc_col-sm-6',
						'dependency'  	=> Array('element' => "is_slider", 'value' => array('1'))
					),
					array(
						"type" 			=> "dropdown",
						"class" 		=> "",
						"heading" 		=> esc_html__("Center Mode", 'wd_package'),
						"admin_label" 	=> true,
						"param_name" 	=> "center_mode",
						"value" 		=> array(
								'Yes' 		=> '1',
								'No' 		=> '0'
							),
						'std'			=> '0',
						"description" 	=> esc_html__("Create highlighter for item at between", 'wd_package'),
						'edit_field_class' => 'vc_col-sm-6',
						'dependency'  	=> Array('element' => "slider_type", 'value' => array('slick'))
					),
					array(
						"type" 			=> "dropdown",
						"class" 		=> "",
						"heading" 		=> esc_html__("Show Nav", 'wd_package'),
						"admin_label" 	=> true,
						"param_name" 	=> "show_nav",
						"value" 		=> array(
								'Yes' 		=> '1',
								'No' 		=> '0'
							),
						"description" 	=> "",
						'edit_field_class' => 'vc_col-sm-6',
						'dependency'  	=> Array('element' => "is_slider", 'value' => array('1'))
					),
					array(
						"type" 			=> "dropdown",
						"class" 		=> "",
						"heading" 		=> esc_html__("Auto Play", 'wd_package'),
						"admin_label" 	=> true,
						"param_name" 	=> "auto_play",
						"value" 		=> array(
								'Yes' 		=> '1',
								'No' 		=> '0'
							),
						"description" 	=> "",
						'edit_field_class' => 'vc_col-sm-6',
						'dependency'  	=> Array('element' => "is_slider", 'value' => array('1'))
					),
					array(
						'type' 			=> 'dropdown',
						'heading' 		=> esc_html__( 'Show Load More', 'wd_package' ),
						'param_name' 	=> 'pagination_loadmore',
						'admin_label' 	=> true,
						'value' 		=> array(
								'Hide'	=> '0',
								'Show'	=> '1'
						),
						'description' 	=> '',
						'edit_field_class' => 'vc_col-sm-6',
						'dependency'  	=> Array('element' => "is_slider", 'value' => array('0'))
					),
					//Global
					array(
						'type' 			=> 'dropdown',
						'heading' 		=> esc_html__( 'Style', 'wd_package' ),
						'param_name' 	=> 'style',
						'admin_label' 	=> true,
						'value' => array(
								'Style 1'	=> 'style-1',
								'Style 2'	=> 'style-2',
								'Style 3'	=> 'style-3',
								'Style 4'	=> 'style-4',
								'Style 5'	=> 'style-5',
								'Style 6'	=> 'style-6',
						),
						'description' 	=> '',
						'edit_field_class' => 'vc_col-sm-6',
					),
					array(
						'type' 			=> 'dropdown',
						'heading' 		=> esc_html__( 'Thumbnail Size', 'wd_package' ),
						'param_name' 	=> 'image_size',
						'admin_label' 	=> true,
						'value' 		=> tvlgiao_wpdance_vc_get_list_image_size(),
						'description' 	=> '',
						'std'			=> 'wd_team_thumb',
						'edit_field_class' => 'vc_col-sm-6',
					),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> esc_html__("Number word content", 'wd_package'),
						'description'	=> esc_html__("", 'wd_package'),
						'admin_label' 	=> true,
						'param_name' 	=> 'number',
						'value' 		=> '100'
					),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> esc_html__("Extra class name", 'wd_package'),
						'description'	=> esc_html__("Style particular content element differently - add a class name and refer to it in custom CSS.", 'wd_package'),
						'admin_label' 	=> true,
						'param_name' 	=> 'class',
						'value' 		=> ''
					)
				)
			));

		} // End Function Shortcode
	}
}
# add theme's custom shortcodes to Visual Composer
add_action('vc_before_init', 'wd_team_vc_shortcodes');
?>