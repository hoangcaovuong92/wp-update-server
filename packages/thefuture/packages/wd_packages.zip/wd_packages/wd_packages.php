<?php 
/*
 * Plugin Name: WD Packages
 * Plugin URI: http://www.wpdance.com
 * Description: Register Post type, taxonomy, style and script library used for WD Team packages ...
 * Version: 2.0.0
 * Author: Cao Vuong - wpdance.com
 * Author URI: http://www.wpdance.com
 * Text Domain: wd_package
 * Domain Path: /languages/
 */
if (!class_exists('WD_Packages')) {
	class WD_Packages {
		/**
		 * Refers to a single instance of this class.
		 */
		private static $instance = null;

		public static function get_instance() {
			if ( null == self::$instance ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		protected $arr_packages = array(
				'wd_shortcode' 		=> array(
						'status' 			=> '1',
						'admin_page_key'	=> 'wd_package_shortcode',
					),
				'wd_portfolio' 		=> array(
						'status' 			=> '1',
						'admin_page_key'	=> 'wd_package_portfolio',
					),
				'wd_megamenu' 			=> array(
						'status' 			=> '1',
						'admin_page_key'	=> 'wd_package_megamenu',
					),
				'wd_team' 			=> array(
						'status' 			=> '1',
						'admin_page_key'	=> 'wd_package_team',
					),
				'wd_testimonials' 	=> array(
						'status' 			=>	 '1',
						'admin_page_key'	=> 'wd_package_testimonials',
					),
				'wd_feature' 		=> array(
						'status' 			=>	 '1',
						'admin_page_key'	=> 'wd_package_feature',
					),
				'wd_pricing_table' 	=> array(
						'status' 			=>	 '1',
						'admin_page_key'	=> 'wd_package_pricing_table',
					),
				'wd_quickshop' 		=> array(
						'status' 			=> '1',
						'admin_page_key'	=> 'wd_package_quickshop',
					),
				'wd_shop_by_color' 	=> array(
						'status' 			=> 	'1',
						'admin_page_key'	=> 'wd_package_shop_by_color',										
					),
			);

		protected $arr_js = array(
				'smooth_scroll' 	=> array(
						'status' 			=> 	'0',
						'admin_page_key'	=> 'wd_package_smooth_croll',										
					),
			);

		public function __construct(){
			$this->constant();
			add_action( 'plugins_loaded', array($this, 'load_textdomain' ));
			$this->get_packages_setting();
			$this->package_function_include();

			add_action('init', array($this, 'init_setup'));
			$this->package_include();

			add_action('wp_enqueue_scripts', array($this, 'front_end_package_js'));
			add_action('admin_enqueue_scripts', array($this, 'back_end_package_js'));
			
			add_filter( 'single_template', array( $this, 'single_header_footer_template' ) );

			// Session
			add_action('init', array($this, 'session_start'), 1);
			add_action('wp_logout', array($this, 'session_end'));
			add_action('wp_login', array($this, 'session_end'));

			$this->plugin_update_checker();
		}

		protected function constant(){
			define('WD_PACKAGE'			,   plugin_dir_path( __FILE__ ) );
			define('WD_PACKAGE_URI'		,   plugins_url( '', __FILE__ ) );
			define('WD_PACKAGE_ASSETS' 	,   WD_PACKAGE_URI. '/assets');
			define('WD_PACKAGE_JS' 		,   WD_PACKAGE_ASSETS. '/js');
			define('WD_PACKAGE_LIBS'	,   WD_PACKAGE_ASSETS. '/libs' );
		}

		protected function plugin_update_checker(){
			require 'plugin-updates/plugin-update-checker.php';
			$Update_Checker = PucFactory::buildUpdateChecker(
				'http://w-shadow.com/files/external-update-example/info.json',
				__FILE__
			);

			//Here's how you can add query arguments to the URL.
			function addSecretKey($query){
				$settings = get_option('my_plugin_settings');
			    if ( !empty($settings['order_number']) ) {
			        $query['order_number'] = $settings['order_number'];
			    }
			    if ( !empty($settings['order_pass']) ) {
			        $query['order_pass'] = $settings['order_pass'];
			    }
			    return $query;
			}
			$Update_Checker->addQueryArgFilter('addSecretKey');
		}

		protected function get_packages_setting(){
			if (get_option('wd_packages')) {
				$parkages = get_option('wd_packages');
				if (!empty($parkages['verify_submit'])) {
					$pre_arr_packages = array();
					foreach ($this->arr_packages as $key => $value) {
						$pre_arr_packages[$key] = (!empty($parkages[$value['admin_page_key']])) ? $parkages[$value['admin_page_key']] : $value['status'];
					}
					$this->arr_packages = $pre_arr_packages;

					$pre_arr_js = array();
					foreach ($this->arr_js as $key => $value) {
						$pre_arr_js[$key] = (!empty($parkages[$value['admin_page_key']])) ? $parkages[$value['admin_page_key']] : $value['status'];
					}

					$this->arr_js = $pre_arr_js;
				}
			}
		}

		// Session start
		public function session_start() {
		    if(!session_id()) {
		    	ini_set('session.save_path', WD_PACKAGE.'/session');
		        session_start();
		    }
		}
		
		// Session clear
		public function session_end() {
			session_destroy();
		}

		public function load_textdomain() {
		  	load_plugin_textdomain( 'wd_package', false, basename( dirname( __FILE__ ) ) . '/languages' ); 
		}

		public function front_end_package_js(){
			//smooth_scroll
			if(!wp_is_mobile() && $this->is_windows() && $this->is_chrome()) { 
				$special_template = is_page_template( 'page-templates/template-home-header-left.php' );
				if($this->arr_js['smooth_scroll'] && !$special_template) {
					wp_enqueue_script( 'tvlgiao-wpdance-smooth-scroll', WD_PACKAGE_LIBS.'/smooth_scroll/jQuery.scrollSpeed.js',array('jquery'),false,true);
					wp_enqueue_script( 'tvlgiao-wpdance-smooth-scroll-run', WD_PACKAGE_LIBS.'/smooth_scroll/run.js',false,false,true);
				}
			}
		}

		public function back_end_package_js(){
			wp_enqueue_style( 'wp-color-picker' );
			wp_enqueue_script( 'wd-media-js', WD_PACKAGE_JS.'/wd_media.js',false,false,true);
		}

		public function package_function_include(){ 
			if(file_exists(WD_PACKAGE."/wd_functions.php")){
				require_once WD_PACKAGE.'/wd_functions.php';
			}
		} 

		public function init_setup(){ 
			$this->register_html_block_post_type();
			$this->admin_page_include();
		} 

		public function admin_page_include(){
			if(file_exists(WD_PACKAGE."/admin_page/admin_page.php")){
				require_once WD_PACKAGE."/admin_page/admin_page.php";
			}
		}

		public function package_include(){
			foreach ($this->arr_packages as $package => $display) {
				if(file_exists(WD_PACKAGE."/{$package}/{$package}.php") && $display == '1'){
					require_once WD_PACKAGE."/{$package}/{$package}.php";
				}
			}
		}

		/******************************** HTML BLOCK POST TYPE ***********************************/
		public function single_header_footer_template( $single ) {
			global $post; 
			if ( ($post->post_type == 'wpdance_header' || $post->post_type == 'wpdance_footer') && file_exists( WD_PACKAGE . '/templates/single-header_footer_template.php' ) ) {
				return WD_PACKAGE . '/templates/single-header_footer_template.php';
			}

			return $single;
		}

		public function register_html_block_post_type(){
			register_post_type('wpdance_header', array(
				'exclude_from_search' => true,
				'labels' => array(
					'name' 					=> esc_html__("Headers HTML", 'wd_package'),
					'singular_name' 		=> esc_html__("Header HTML", 'wd_package'),
		        	'add_new' 				=> esc_html__( 'Add New', 'wd_package' ),
					'add_new_item' 			=> sprintf( __( 'Add New %s', 'wd_package' ), __( 'Header HTML', 'wd_package' ) ),
					'edit_item' 			=> sprintf( __( 'Edit %s', 'wd_package' ), __( 'Header HTML', 'wd_package' ) ),
					'new_item' 				=> sprintf( __( 'New %s', 'wd_package' ), __( 'Header HTML', 'wd_package' ) ),
					'all_items' 			=> sprintf( __( 'All %s', 'wd_package' ), __( 'Headers HTML', 'wd_package' ) ),
					'view_item' 			=> sprintf( __( 'View %s', 'wd_package' ), __( 'Header HTML', 'wd_package' ) ),
					'search_items' 			=> sprintf( __( 'Search %a', 'wd_package' ), __( 'Headers HTML', 'wd_package' ) ),
					'not_found' 			=>  sprintf( __( 'No %s Found', 'wd_package' ), __( 'Headers HTML', 'wd_package' ) ),
					'not_found_in_trash' 	=> sprintf( __( 'No %s Found In Trash', 'wd_package' ), __( 'Headers HTML', 'wd_package' ) ),
				),
				'public' 				=> true,
				'has_archive' 			=> false,
				'menu_icon'				=> 'dashicons-editor-table',
				'menu_position'			=> 21,
			));
			register_post_type('wpdance_footer', array(
				'exclude_from_search' => true,
				'labels' => array(
					'name' 					=> esc_html__("Footers HTML", 'wd_package'),
					'singular_name' 		=> esc_html__("Footer HTML", 'wd_package'),
		        	'add_new' 				=> esc_html__( 'Add New', 'wd_package' ),
					'add_new_item' 			=> sprintf( __( 'Add New %s', 'wd_package' ), __( 'Footer HTML', 'wd_package' ) ),
					'edit_item' 			=> sprintf( __( 'Edit %s', 'wd_package' ), __( 'Footer HTML', 'wd_package' ) ),
					'new_item' 				=> sprintf( __( 'New %s', 'wd_package' ), __( 'Footer HTML', 'wd_package' ) ),
					'all_items' 			=> sprintf( __( 'All %s', 'wd_package' ), __( 'Footers HTML', 'wd_package' ) ),
					'view_item' 			=> sprintf( __( 'View %s', 'wd_package' ), __( 'Footer HTML', 'wd_package' ) ),
					'search_items' 			=> sprintf( __( 'Search %a', 'wd_package' ), __( 'Footers HTML', 'wd_package' ) ),
					'not_found' 			=>  sprintf( __( 'No %s Found', 'wd_package' ), __( 'Footers HTML', 'wd_package' ) ),
					'not_found_in_trash' 	=> sprintf( __( 'No %s Found In Trash', 'wd_package' ), __( 'Footers Template', 'wd_package' ) ),
				),
				'public' 				=> true,
				'has_archive' 			=> false,
				'menu_icon'				=> 'dashicons-editor-table',
				'menu_position'			=> 21,
			));
			add_post_type_support( 'wpdance_header', 'thumbnail' );
			add_post_type_support( 'wpdance_footer', 'thumbnail' );
		}

		public function is_windows(){
			$u = $_SERVER['HTTP_USER_AGENT'];
			$window  = (bool)preg_match('/Windows/i', $u );
			return $window;
		}
		public function is_chrome(){
			$u = $_SERVER['HTTP_USER_AGENT'];
			$chrome  = (bool)preg_match('/Chrome/i', $u );
			return $chrome;
		}
	}
	WD_Packages::get_instance();
}
?>