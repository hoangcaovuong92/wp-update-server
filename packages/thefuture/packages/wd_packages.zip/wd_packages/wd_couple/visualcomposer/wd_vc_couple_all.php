<?php
	// Couple Infomation
	vc_map(array(
		'name' 				=> esc_html__("WD All Couple", 'wd_package'),
		'base' 				=> 'tvlgiao_wpdance_couple_all_data',
		'description' 		=> esc_html__("WD All Couple", 'wd_package'),
		'category' 			=> esc_html__('wd_package', 'wd_package'),
		"params" => array(
			array(
				'type' 			=> 'textfield',
				'class' 		=> '',
				'heading' 		=> esc_html__("Number Couple", 'wd_package'),
				'description'	=> esc_html__("Number Couple", 'wd_package'),
				'admin_label' 	=> true,
				'param_name' 	=> 'number_couple',
				'value' 		=> '6'
			),
			array(
				'type' 			=> 'dropdown',
				'class' 		=> '',
				'heading' 		=> esc_html__("Column Couple", 'wd_package'),
				'description'	=> esc_html__("Column Couple", 'wd_package'),
				'admin_label' 	=> true,
				'param_name' 	=> 'column_couple',
				'value' 		=> array(
						'02 Columns'		=> '2',
						'03 Columns'		=> '3',
						'04 Columns'		=> '4',
						'06 Columns'		=> '6',
					)
				,'description' => ''
			),
			array(
				'type' 			=> 'textfield',
				'class' 		=> '',
				'heading' 		=> esc_html__("Extra class name", 'wd_package'),
				'description'	=> esc_html__("Style particular content element differently - add a class name and refer to it in custom CSS.", 'wd_package'),
				'admin_label' 	=> true,
				'param_name' 	=> 'class',
				'value' 		=> ''
			)
		)
	));
?>