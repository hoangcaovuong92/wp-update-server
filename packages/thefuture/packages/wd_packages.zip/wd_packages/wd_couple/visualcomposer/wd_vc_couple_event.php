<?php
	// Couple Infomation
	vc_map(array(
		'name' 				=> esc_html__("WD Couple Event", 'wd_package'),
		'base' 				=> 'tvlgiao_wpdance_couple_event',
		'description' 		=> esc_html__("WD Couple Event", 'wd_package'),
		'category' 			=> esc_html__('wd_package', 'wd_package'),
		"params" => array(
			array(
				'type' 			=> 'dropdown',
				'heading' 		=> esc_html__( 'Style Event', 'wd_package' ),
				'param_name' 	=> 'event_style',
				'admin_label' 	=> true,
				'value' 		=> array(
						'Style 1'		=> 'wd-event-style-1',
						'Style 2'		=> 'wd-event-style-2',
					),
				'description' 	=> '',
			),
			array(
				"type" 			=> "textfield",
				"class" 		=> "",
				"heading" 		=> esc_html__("Event Title", 'wd_package'),
				"param_name" 	=> "event_title",
				"description" 	=> '',
			),
			array(
				"type" 			=> "attach_image",
				"class" 		=> "",
				"heading" 		=> esc_html__("Event Icon", 'wd_package'),
				"param_name" 	=> "event_icon",
				"value" 		=> "",
			),
			array(
				"type" 			=> "textfield",
				"class" 		=> "",
				"heading" 		=> esc_html__("Event Location", 'wd_package'),
				"param_name" 	=> "event_location",
				"description" 	=> '',
			),
			array(
				"type" 			=> "textfield",
				"class" 		=> "",
				"heading" 		=> esc_html__("Event Date", 'wd_package'),
				"param_name" 	=> "event_date",
				"description" 	=> '',
			),
			array(
				"type" 			=> "textfield",
				"class" 		=> "",
				"heading" 		=> esc_html__("Event Time", 'wd_package'),
				"param_name" 	=> "event_time",
				"description" 	=> '',
			),
			array(
				'type' 			=> 'dropdown',
				'heading' 		=> esc_html__( 'Show Description', 'wd_package' ),
				'param_name' 	=> 'event_show_des',
				'value' 		=> array(
						'No'		=> '0',
						'Yes'		=> '1',
					),
				'description' 	=> '',
			),			
			array(
				"type" 			=> "textarea",
				"class" 		=> "",
				"heading" 		=> esc_html__("Description Timeline", 'wd_package'),
				"param_name" 	=> "event_description",
				"description" 	=> '',
				'dependency'  	=> Array('element' => "event_show_des", 'value' => array('1'))
			),
			array(
				'type' 			=> 'dropdown',
				'heading' 		=> esc_html__( 'Show View Map', 'wd_package' ),
				'param_name' 	=> 'event_show_map',
				'value' 		=> array(
						'No'		=> '0',
						'Yes'		=> '1',
					),
				'description' 	=> '',
			),	
			array(
				"type" 			=> "textfield",
				"class" 		=> "",
				"heading" 		=> esc_html__("URL MAP", 'wd_package'),
				"param_name" 	=> "event_url_map",
				"description" 	=> '',
				'dependency'  	=> Array('element' => "event_show_map", 'value' => array('1'))
			),
			array(
				'type' 			=> 'textfield',
				'class' 		=> '',
				'heading' 		=> esc_html__("Extra class name", 'wd_package'),
				'description'	=> esc_html__("Style particular content element differently - add a class name and refer to it in custom CSS.", 'wd_package'),
				'admin_label' 	=> true,
				'param_name' 	=> 'class',
				'value' 		=> '',
			),
		)
	));
?>