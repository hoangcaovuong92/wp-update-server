//****************************************************************//
/*							Ajax Loadmore JS					  */
//****************************************************************//
jQuery( document ).ready( function($) {
	//hide loading button
	$(".show_image_loading").hide(); 

	//Ajax loadmore product. 
	//Template: wd_product_best_selling.php / wd_product_grid_list.php / wd_product_special_slider.php 
	wd_ajax_load_more_product_basic();

	//Ajax load product tab. Template: wd_product_by_category_tabs.php
	wd_ajax_load_more_product_tabs();

	//Ajax loadmore blog masonry. Template: wd_blog_mansory.php
	wd_ajax_load_more_blog_masonry();

	//Ajax loadmore blog. Template: wd_blog_grid_list.php
	wd_ajax_load_more_blog_grid_list();
});

//****************************************************************//
/*                          FUNCTIONS                             */
//****************************************************************//
//Ajax loadmore product. 
//Template: wd_product_best_selling.php / wd_product_grid_list.php / wd_product_special_slider.php 
if (typeof wd_ajax_load_more_product_basic != 'function') { 
	function wd_ajax_load_more_product_basic(){
		jQuery(document).on ( 'click', '.btn_loadmore_product', function( event ) {
			event.preventDefault();
			var post_type 				= 'product'; // this is optional and can be set from anywhere, stored in mockup etc...
			var _this 					= jQuery(this);
			var select_item_parent  	= _this.parents('.wd-wrapper-parents-value');
			var select_content_item 	= select_item_parent.find('.wd-products-wrapper').find('.products');
			var offset 					= select_content_item.children().length;

			var random_id 				= jQuery(this).data("random_id");
			var posts_per_page 			= jQuery(this).data("posts_per_page");
			var id_category 			= jQuery(this).data("id_category");
			var data_show 				= jQuery(this).data("data_show");
			var sort 					= jQuery(this).data("sort");
			var order_by 				= jQuery(this).data("order_by");
			jQuery.ajax({
				url: ajax_object.ajax_url,
				type: 'post',
				data: {
					action			: 'load_more_product',
					query_vars		: ajax_object.query_vars,
					offset			: offset, 
					post_type		: post_type,
					posts_per_page	: posts_per_page,
					category_id		: id_category,
					data_show		: data_show,
					sort			: sort,
					order_by		: order_by,
				},

				beforeSend: function(data) {
					jQuery("#show_image_loading_"+random_id).show();
				},
				success: function( response ) {
					jQuery("#show_image_loading_"+random_id).hide();
					select_content_item.append(response);
					if (document.getElementById('tvlgiao_have_post') !=null) {
						var wd_status = select_item_parent.find('#tvlgiao_have_post').val();
						if(wd_status == 1){
							_this.removeClass('btn_loadmore_product').addClass('btn_end_load_more').html('END OF POSTS');
						}
					}
					jQuery('.products .product').find('.wp_description_product.wd_hidden_desc_product').addClass('hidden');
	   				jQuery('.products .product').find('.wp_description_product.wd_show_desc_product').removeClass('hidden');
				}
			});
		});
	}	
}

//Ajax load product tab. Template: wd_product_by_category_tabs.php
if (typeof wd_ajax_load_more_product_tabs != 'function') { 
	function wd_ajax_load_more_product_tabs(){
		jQuery( '.products-by-category-tabs a[data-toggle="tab"]' ).on( 'show.bs.tab', function ( e ) {
			const type    				= jQuery( this ).data( 'type' );
			const slug    				= jQuery( this ).data( 'slug' );
			const id      				= jQuery( this ).data( 'id' );
			const sort   				= jQuery( this ).data( 'sort' );
			const orderby 				= jQuery( this ).data( 'orderby' );
			const columns 				= jQuery( this ).data( 'columns' );
			const columns_tablet 		= jQuery( this ).data( 'columns_tablet' );
			const columns_mobile 		= jQuery( this ).data( 'columns_mobile' );
			const posts_per_page 		= jQuery( this ).data( 'posts_per_page' );
			const is_slider 			= jQuery( this ).data( 'is_slider' );
			const mansory_layout 		= jQuery( this ).data( 'mansory_layout' );
			const mansory_image_size 	= jQuery( this ).data( 'mansory_image_size' );
			const show_category_thumb 	= jQuery( this ).data( 'show_category_thumb' );
			const show_nav 				= jQuery( this ).data( 'show_nav' );
			const auto_play 			= jQuery( this ).data( 'auto_play' );
			const per_slide 			= jQuery( this ).data( 'per_slide' );

			if ( jQuery( jQuery( this ).attr( 'href' ) ).data( 'load' ) === 'loading' ) {
				const that = jQuery( this );
				jQuery.ajax( {
					url: ajax_object.ajax_url,
					type: 'post',
					data: {
						action				: 'product_by_category_tabs',
						type				: type,
						slug				: slug,
						id					: id,
						sort				: sort,
						orderby				: orderby,
						columns				: columns,
						columns_tablet		: columns_tablet,
						columns_mobile		: columns_mobile,
						posts_per_page		: posts_per_page,
						is_slider			: is_slider,
						mansory_layout		: mansory_layout,
						mansory_image_size	: mansory_image_size,
						show_category_thumb	: show_category_thumb,
						show_nav			: show_nav,
						auto_play			: auto_play,
						per_slide			: per_slide,
					},
					error: function ( response ) {
						console.log( response );
					},
					success: function ( response ) {
						jQuery( that.attr( 'href' ) ).html( response );
						jQuery( that.attr( 'href' ) ).data( 'load', 'loaded' ).attr( 'data-load', 'loaded' );
						jQuery('.products .product').find('.wp_description_product.wd_hidden_desc_product').addClass('hidden');
	   					jQuery('.products .product').find('.wp_description_product.wd_show_desc_product').removeClass('hidden');
	   					if (typeof qs_prettyPhoto == 'function') { qs_prettyPhoto(); }
					}
				} );
			}
		} );
	}	
}

//Ajax loadmore blog masonry. Template: wd_blog_mansory.php
if (typeof wd_ajax_load_more_blog_masonry != 'function') { 
	function wd_ajax_load_more_blog_masonry(){
		jQuery(document).on ( 'click', '.btn_loadmore_masonry', function( event ) {
			var page 	= 1; // What page we are on.
			var offset 	= jQuery('.grid .grid-item').length;

			var random_id 		= jQuery(this).data("random_id");
			var posts_per_page 	= jQuery(this).data("posts_per_page");
			var columns			= jQuery(this).data("columns");	 

			jQuery('#show_image_loading_'+random_id).css( "display", "block" );
			jQuery( '.grid' ).find( '#wd_status' ).remove();
			jQuery.post(blog_ajax_object.ajax_url_blog, {
				action			: "load_more_post_masonry",
				offset			: offset,
				posts_per_page	: posts_per_page,
				columns			: columns
			}).success(function(posts){
				jQuery("#show_image_loading_"+random_id).css( "display", "none" );
				var $newItems = jQuery(posts);
				jQuery('.grid').append( $newItems ).isotope( 'addItems', $newItems );

				wd_load_isotope();
			
				var $item = jQuery('<div class="grid-item" id="remove-grid-item"></div>');
				jQuery('.grid').append( $item ).isotope( 'addItems', $item );
				wd_load_isotope();
				jQuery( '.grid' ).find( '#remove-grid-item' ).remove();

				var wd_status = document.getElementById('wp_outline_have_post').value;				
				if(wd_status == 0){
					jQuery(".load_more_masonry a").removeClass('btn_loadmore_masonry').addClass('btn_end_load_more_masonry').html('END OF POSTS');
				}
				setTimeout(
				function(){
				    wd_load_isotope();
				}, 1000);						
			});
		});
	}	
}

//Ajax loadmore blog. Template: wd_blog_grid_list.php
if (typeof wd_ajax_load_more_blog_grid_list != 'function') { 
	function wd_ajax_load_more_blog_grid_list(){
		jQuery(document).on ( 'click', '.btn_loadmore_blog', function( event ) {
			event.preventDefault();
			var post_type 						= 'post'; // this is optional and can be set from anywhere, stored in mockup etc...
			var offset 							= jQuery('.wd-shortcode-special-blog .wd-load-more-content-blog').length;

			var random_id 						= jQuery(this).data("random_id");
			var posts_per_page 					= jQuery(this).data("posts_per_page");
			var id_category 					= jQuery(this).data("id_category");
			var data_show 						= jQuery(this).data("data_show");
			var columns 						= jQuery(this).data("columns");
			var show_data_image_slider 			= jQuery(this).data("show_data_image_slider");
			var grid_list_layout 				= jQuery(this).data("grid_list_layout");
			var sort 							= jQuery(this).data("sort");
			var order_by 						= jQuery(this).data("order_by");
			jQuery.ajax({
				url: blog_ajax_object.ajax_url_blog,
				type: 'post',
				data: {
					action						:'load_more_blog',
					query_vars					: ajax_object.query_vars,
					offset						: offset, 
					post_type					: post_type,
					posts_per_page				: posts_per_page,
					category_id					: id_category,
					data_show					: data_show,
					columns 					: columns,
					show_show_data_image_slider	: show_data_image_slider, 
					grid_list_layout			: grid_list_layout,
					sort						: sort,
					order_by					: order_by,
				},

				beforeSend: function(data) {
					jQuery("#show_image_loading_"+random_id).show();
				},
				success: function( response ) {
					jQuery("#show_image_loading_"+random_id).hide();
					jQuery( '.wd-shortcode-special-blog' ).append(response);
					if (document.getElementById('tvlgiao_have_post') !=null) {
						var wd_status = document.getElementById('tvlgiao_have_post').value;
						if(wd_status == 1){
							jQuery("#loadmore a").removeClass('btn_loadmore_product').addClass('btn_end_load_more').html('END OF POSTS');
						}
					}

				}
			});
		});
	}	
}