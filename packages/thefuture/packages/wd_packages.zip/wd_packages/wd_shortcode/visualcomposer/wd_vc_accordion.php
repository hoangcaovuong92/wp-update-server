<?php
vc_map( array(
	'name'        => __( "WD - Accordion", 'wd_package' ),
	'description' => __( "Show Accordion FAQs...", 'wd_package' ),
	'base'        => 'tvlgiao_wpdance_accordion',
	"category"    => esc_html__("WPDance Shortcode", 'wd_package'),
	'icon'        => 'icon-wpb-ui-accordion',
	'params'      => array(
		array(
            'type' 			=> 'param_group',
            'value' 		=> '',
            'param_name' 	=> 'items',
            // Note params is mapped inside param-group:
            'params' 		=> array(
            	array(
					"type" 			=> "textfield",
					"holder" 		=> "div",
					"class" 		=> "",
					"heading" 		=> esc_html__("Title", 'wd_package'),
					"param_name" 	=> "title",
					"value" 		=> "",
					"description" 	=> esc_html__("", 'wd_package')
				),
            	array(
					"type" 			=> "textarea",
					"holder" 		=> "div",
					"class" 		=> "",
					"heading" 		=> esc_html__("Content", 'wd_package'),
					"param_name" 	=> "content",
					"value" 		=> "",
					"description" 	=> esc_html__("HTML/Shortcode/Text is allowed.", 'wd_package')
				),
            )
        ),
        array(
			"type" 				=> "dropdown",
			"class" 			=> "",
			"heading" 			=> esc_html__("Show Icon", 'wd_package'),
			"admin_label" 		=> true,
			"param_name" 		=> "show_icon",
			"value" 			=> array(
					'Yes' 		=> '1',
					'No' 		=> '0'
				),
			"description" 		=> "",
		),
        array(
			'type' 				=> 'iconpicker',
			'heading' 			=> esc_html__( 'Icon Plus', 'wd_package' ),
			'param_name' 		=> 'icon_plus',
			'value' 			=> '',
			'settings' 			=> array(
				'emptyIcon' 		=> false,
				'iconsPerPage' 		=> 4000,
			),
			'std'				=> 'fa fa-plus',
			'description' 		=> esc_html__( 'Select icon from library.', 'wd_package' ),
			'edit_field_class' 	=> 'vc_col-sm-6',
			'dependency'		=> Array('element' => "show_icon", 'value' => array('1'))
		),
    	
		array(
			'type' 				=> 'iconpicker',
			'heading' 			=> esc_html__( 'Icon Minus', 'wd_package' ),
			'param_name' 		=> 'icon_minus',
			'value' 			=> '',
			'settings' 			=> array(
				'emptyIcon' 		=> false,
				'iconsPerPage' 		=> 4000,
			),
			'std'				=> 'fa fa-minus',
			'description' 		=> esc_html__( 'Select icon from library.', 'wd_package' ),
			'edit_field_class' 	=> 'vc_col-sm-6',
			'dependency'		=> Array('element' => "excerpt", 'value' => array('1'))
		),
		array(
			'type' 				=> 'dropdown',
			'heading' 			=> esc_html__( 'Style', 'wd_package' ),
			'param_name' 		=> 'style_class',
			'admin_label' 		=> true,
			'value' 			=> tvlgiao_wpdance_get_list_style_class(5),
			'description' 		=> '',
		),
		array(
			'type' 				=> 'textfield',
			'class' 			=> '',
			'heading' 			=> esc_html__("Extra class name", 'wd_package'),
			'description'		=> esc_html__("Style particular content element differently - add a class name and refer to it in custom CSS.", 'wd_package'),
			'admin_label' 		=> true,
			'param_name' 		=> 'class',
			'value' 			=> ''
		),
	)
) );