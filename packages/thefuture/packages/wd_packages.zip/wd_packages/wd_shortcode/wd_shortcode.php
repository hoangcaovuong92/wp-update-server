<?php
if (!class_exists('WD_Shortcode')) {
	class WD_Shortcode{
		/**
		 * Refers to a single instance of this class.
		 */
		private static $instance = null;

		public static function get_instance() {
			if ( null == self::$instance ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		protected $parkage_name 		= '/wd_shortcode';
		protected $arrShortcodes 		= array();
		protected $arrWidgets 			= array();
		protected $arr_packages 		= array(
						'faq_post_type' => array(
							'status' 	=>	 '1',
							'meta_key'	=> 'wd_package_testimonials',
						),
						'widget'		=> array(
							'status' 	=>	 '1',
							'meta_key'	=> 'wd_package_widget',
						),	
					);

		public function __construct(){
			$this->constant();

			// Get setting from admin page
			$this->get_packages_setting();

			//Include Class
			$this->register_classes();

			// Register Woocommerce Brands taxonomy
			$this->register_woo_brand_taxonomy();

			// Register Faq post type & taxonomy
			if ($this->arr_packages['faq_post_type']) {
				$this->register_faq_post_type();
			}

			// Register Script
			add_action('wp_enqueue_scripts', array( $this, 'init_script' ));
			add_action('wp_enqueue_scripts', array( $this, 'set_ajax_url' ));
			add_action('admin_enqueue_scripts', array( $this, 'admin_init_script' ));
			
			$this->initArrShortcodes();
			$this->initArrWidgets(); 

			//Widgets
			if ($this->arr_packages['widget']) {
				$this->initWidgets(); 
			}

			//Visual Composer
			$this->initShortcodes();
			if($this->checkPluginVC()){
				if ( ! defined( 'ABSPATH' ) ) { exit; }
				add_action("vc_after_init",array($this,'initVisualComposer'));
			}
		}

		protected function initArrShortcodes(){
			$this->arrShortcodes 		= array(
				'title',
				'site_header',
				'uber_menu',
				'do_shortcode',
				'my_account',
				'social_profiles',
				'social_fanpage_likebox',

				'button',
				'banner_image',
				'banner_image_plus',
				'banner_slider',
				'brand_slider',
				'text_slider',
				'twitter_slider',

				'blog_search',
				'blog_grid_list',
				'blog_special',
				'blog_masonry',
				'blog_recent_slider',

				'dropdowncart',
				'currency_switcher',
				'wishlist',
				'product_search',
				'product_grid_list',
				'product_special_slider',
				'product_simple_slider',
				'product_single_detail',
				'product_category_single',
				'product_categories',
				'product_best_selling',
				'product_categories_tabs',
				'product_categories_group',
				'product_categories_accordion',
				'product_categories_list',
				
				'gtranslate',
				'fullpage',
				'instagram',
				'instagram_masonry',
				'instagram_snapppt',
				'icon_count',
				'icon_payment',
				'count_down',
				'feedburner_subscription',
				'faq',
				'pages_list',
				'accordion',
				'process_bar',
				'quote',
				'information',
		 		'skill',
		 		'recent_comment',
	 		);
		}

		protected function initArrWidgets(){
			$this->arrWidgets 		= array(
				'wd_banner_image',
				/*'banner_ads',
				'countdown',
				'title_heading',
				'faq',
				'testimonials',
				'testimonials_plus',
				'header_dropdown_cart',
				'header_user_login',
				'header_site_logo',
				'header_icon_group',
				'header_wishlist_button',
				'product_slider',
				'product_grid_list',
				'product_special',
				'product_countdown',*/
				'blog_special',
				/*'blog_grid_list',
				'special_post',
				'woo_currency_switcher',
				'woo_brand_slider',*/
				'instagram',
				/*'team_members',
				'pricing_table',
				'feature',
				'feature_category',
				'feedburner_subscription',
				'category_list_child',*/
				'search_product',
				'search_blog',
				'icon_social',
				'icon_payment',
				'fanpage_likebox',
				'product_categories_accordion',
			);
		}

		protected function constant(){
			define('SC_BASE'		,   plugin_dir_path( __FILE__ ) );
			define('SC_BASE_URI'	,   plugins_url( '', __FILE__ ) );
			define('SC_CLASS'		, 	SC_BASE . '/classes' 		);
			define('SC_SHORTCODE'	, 	SC_BASE . '/shortcode' 		);
			define('SC_VISUAL'		, 	SC_BASE . '/visualcomposer' );
			define('SC_WIDGET'		, 	SC_BASE . '/widgets' 		);
			define('SC_POST_TYPE'	, 	SC_BASE . '/post_type' 		);
			define('SC_POST_TYPE_URI', 	SC_BASE_URI . '/post_type' 	);
			define('SC_POST_TYPE_JS', 	SC_POST_TYPE_URI . '/js' 	);
			define('SC_ASSET'		, 	SC_BASE_URI  . '/assets'	);
			define('SC_JS'			, 	SC_ASSET . '/js'			);
			define('SC_CSS'			, 	SC_ASSET . '/css'			);
			define('SC_IMAGE'		, 	SC_ASSET . '/images'		);
			define('SC_LIBS'		, 	SC_ASSET . '/libs'			);
			define('SC_PARAMS'		, 	SC_BASE  . '/vc_params'		);
			define('SC_PARAMS_URI'	, 	SC_BASE_URI  . '/vc_params'	);
			define('SC_PARAMS_JS'	, 	SC_PARAMS_URI . '/js'		);
		}

		protected function get_packages_setting(){
			if (get_option('wd_packages')) {
				$parkages 	= get_option('wd_packages');
				if (!empty($parkages['verify_submit'])) {
					$pre_arr_packages = array();
					foreach ($this->arr_packages as $key => $value) {
						$pre_arr_packages[$key] = (!empty($parkages[$value['meta_key']])) ? $parkages[$value['meta_key']] : $value['status'];
					}
					$this->arr_packages = $pre_arr_packages;
				}
			}
		}

		/***************************** CLASSES **********************************/
		public function register_classes(){
			if( file_exists(SC_CLASS.'/tweetphp/TweetPHP.php') ){
				require_once SC_CLASS.'/tweetphp/TweetPHP.php';
			}	
		}

		/***************************** WOOCOMMERCE BRANDS **********************************/
		public function register_woo_brand_taxonomy(){
			if( file_exists(SC_POST_TYPE.'/taxonomy_brand.php') ){
				require_once SC_POST_TYPE.'/taxonomy_brand.php';
			}	
		}

		/******************************* FAQS POST TYPE ***********************************/
		public function register_faq_post_type(){
			if( file_exists(SC_POST_TYPE.'/faq.php') ){
				require_once SC_POST_TYPE.'/faq.php';
			}	
		}

		/******************************** INIT ***********************************/
		protected function initLibrary(){
			if( file_exists(SC_BASE.'/wd_ajax_loadmore.php') ){
				require_once SC_BASE.'/wd_ajax_loadmore.php';
			}	
			if( file_exists(SC_PARAMS.'/wd_add_param_vc.php') ){
				require_once SC_PARAMS.'/wd_add_param_vc.php';
			}	
		}

		protected function initShortcodes(){
			foreach($this->arrShortcodes as $shortcode){
				if( file_exists(SC_SHORTCODE."/wd_{$shortcode}.php") ){
					require_once SC_SHORTCODE."/wd_{$shortcode}.php";
				}	
			}
		}

		public function initVisualComposer(){ 
			foreach ($this->arrShortcodes as $visual) {
				if( file_exists(SC_VISUAL."/wd_vc_{$visual}.php") ){
					require_once SC_VISUAL."/wd_vc_{$visual}.php";
				}
			}
	    }

		protected function initWidgets(){
			foreach($this->arrWidgets as $widget){
				if( file_exists(SC_WIDGET."/wd_{$widget}.php") ){
					require_once SC_WIDGET."/wd_{$widget}.php";
				}	
			}
		}
		
		public function init_script(){
			//LIBS
			wp_enqueue_style('jquery-ui-core');
			wp_enqueue_style('font-awesome', 					SC_LIBS.'/font-awesome/css/font-awesome.min.css');
			wp_enqueue_style('linearicons', 					SC_LIBS.'/linearicons/icon-font.css');
			wp_enqueue_style('timecircles-core', 				SC_LIBS.'/timecircles/css/timecircles.css');
			wp_enqueue_style('owl-carousel-core', 				SC_LIBS.'/owl-carousel/css/owl.carousel.min.css');
			wp_enqueue_style('slick-core',						SC_LIBS.'/slick/slick.css');
			wp_enqueue_style('slick-theme-css',					SC_LIBS.'/slick/slick-theme.css');
			wp_enqueue_style('select2-core',					SC_LIBS.'/select2/css/select2.min.css'); 

			wp_enqueue_style('jquery-fancybox', 				SC_LIBS.'/fancybox/jquery.fancybox.css', array(), false, 'all' );
			wp_enqueue_style('jquery-fancybox-buttons', 		SC_LIBS.'/fancybox/helpers/jquery.fancybox-buttons.css', array(), false, 'all' );
			wp_enqueue_style('jquery-fancybox-thumbs', 			SC_LIBS.'/fancybox/helpers/jquery.fancybox-thumbs.css', array(), false, 'all' );

			//PLUGIN CSS
			wp_enqueue_style('wd-shortcode-custom-css',			SC_CSS.'/wd_custom_style.css');

			//LIBS
			wp_enqueue_script('jquery');
			//wp_enqueue_script('hoverIntent');
			wp_enqueue_script('bootstrap-core', 				SC_LIBS.'/bootstrap/js/bootstrap.min.js',false,false,true);
			wp_enqueue_script('jquery-countdown-core', 			SC_LIBS.'/jquery-countdown/js/jquery.countdown.min.js',array('jquery'),false,true);
			wp_enqueue_script('jquery-ui-core');
			wp_enqueue_script('timecircles-core', 				SC_LIBS.'/timecircles/js/timecircles.js',false,false,true);
			wp_enqueue_script('owl-carousel-core', 				SC_LIBS.'/owl-carousel/js/owl.carousel.min.js',false,false,true);
			wp_enqueue_script('slick-core', 					SC_LIBS.'/slick/slick.min.js',false,false,true);
			wp_enqueue_script('select2-core', 					SC_LIBS.'/select2/js/select2.min.js',false,false,true);
			wp_enqueue_script('jquery-cookie-core', 			SC_LIBS.'/jquery-dcjqaccordion/js/js.cookie.min.js',false,false,true);
			wp_enqueue_script('jquery-dcjqaccordion-core', 		SC_LIBS.'/jquery-dcjqaccordion/js/jquery.dcjqaccordion.2.7.min.js',false,false,true);
			//wp_enqueue_script( 'jquery-animation-counter',		SC_LIBS.'/jquery-animation-counter/animationCounter.min.js', array( 'jquery' ), false, true);
			wp_enqueue_script( 'jquery-smooth-circle-chart',	SC_LIBS.'/jquery-smooth-circle-chart/jquery.circlechart.js', array( 'jquery' ), false, true);
			
			wp_enqueue_script( 'jquery-mousewheel',				SC_LIBS.'/fancybox/jquery.mousewheel.pack.js', array( 'jquery' ), false, true);
			wp_enqueue_script( 'jquery-fancybox-pack', 			SC_LIBS.'/fancybox/jquery.fancybox.pack.js', false, false, true);
			wp_enqueue_script( 'jquery-fancybox-buttons', 		SC_LIBS.'/fancybox/helpers/jquery.fancybox-buttons.js', false, false, true);
			wp_enqueue_script( 'jquery-fancybox-thumbs', 		SC_LIBS.'/fancybox/helpers/jquery.fancybox-thumbs.js', false, false, true);
			wp_enqueue_script( 'jquery-fancybox-media', 		SC_LIBS.'/fancybox/helpers/jquery.fancybox-media.js', false, false, true);

			//PLUGIN JS
			wp_enqueue_script('wd-shortcode-custom-script',		SC_JS.'/wd_shortcode.js',false,false,true);
			wp_enqueue_script('wd-ajax-pagination-script', 		SC_JS.'/wd_ajax.js',false,false,true);
		}
		public function admin_init_script($hook){
			if ($hook != 'toplevel_page_WPDanceLaParis') {
				wp_enqueue_style('jquery-ui-core');
				wp_enqueue_script('jquery-ui-core');
			}
			wp_enqueue_script( 'jquery-ui-datepicker');
		}		

		/******************************** AJAX ***********************************/
		public function set_ajax_url() {
		 	global $wp_query;
		 	wp_localize_script( 'wd-ajax-pagination-script', 'ajax_object', array(
				'ajax_url' 			=> admin_url( 'admin-ajax.php' ),
				'query_vars'		=> json_encode( $wp_query->query )
			));
		 	wp_localize_script( 'wd-ajax-pagination-script', 'blog_ajax_object', array(
				'ajax_url_blog' 	=> admin_url( 'admin-ajax.php' ),
				'query_vars'		=> json_encode( $wp_query->query )
			));
		 	wp_localize_script( 'wd-ajax-pagination-script', 'masonry_ajax_object', array(
				'ajax_url_masonry' 	=> admin_url( 'admin-ajax.php' ),
				'query_vars'		=> json_encode( $wp_query->query )
			));
		}
		
		/******************************** Check Visual Composer active ***********************************/
		protected function checkPluginVC(){
			$_active_vc = apply_filters('active_plugins',get_option('active_plugins'));
			if(in_array('js_composer/js_composer.php',$_active_vc)){
				return true;
			}else{
				return false;
			}
		}
	}	
	WD_Shortcode::get_instance();
}
?>