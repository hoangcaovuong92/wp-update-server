<?php
/**
 * Shortcode: tvlgiao_wpdance_title
 */

if (!function_exists('tvlgiao_wpdance_title_function')) {
	function tvlgiao_wpdance_title_function($atts) {
		extract(shortcode_atts(array(
			'title'				=> '',
			'title_highlight'	=> '',
			'description'		=> '',
			'heading_type'		=> 'wd-title-section-style-1',
			'title_color'		=> '',
			'desc_color'		=> '',
			'heading_element'	=> 'h2',
			'text_align'		=> 'text-left',
			'display_button'	=> '0',
			'button_text'		=> 'View All',
			'button_url'		=> '#',
			'class' 			=> ''
		), $atts));
		$title_color 	= $title_color != '' ? 'style="color: '.$title_color.';"' : '';
		$desc_color 	= $desc_color != '' ? 'style="color: '.$desc_color.';"' : '';
		ob_start(); ?>
			<?php if($title != "" || $description != "" || $display_button) : ?>
				<div class="wd-title <?php echo esc_attr($heading_type); ?> <?php echo esc_attr($class); ?>">
					<?php if ($title != ''): ?>
						<?php $title = ($title_highlight != '') ? str_replace($title_highlight, '<span class="wd-title-highlight">'.$title_highlight.'</span>', $title) : esc_html($title); ?>
						<<?php echo esc_html($heading_element); ?> class="wd-title-heading <?php echo esc_html($text_align); ?>" <?php echo $title_color; ?>><?php echo $title; ?></<?php echo esc_html($heading_element); ?>>		
					<?php endif ?>		
					<?php if($description != "" || $display_button) : ?>
						<div class="wd-title-description <?php echo esc_html($text_align); ?>" <?php echo $desc_color; ?>>
							<?php if ($description != ''): ?>
								<?php echo esc_html($description); ?>
							<?php endif ?>
							<?php if($description != "" && $display_button) : ?>
								<?php _e(' | ','wd_package') ?>
							<?php endif; ?>
							<?php if($display_button) : ?>
								<a target="_blank" href="<?php echo esc_url($button_url);?>"><?php echo esc_html($button_text); ?></a>
							<?php endif; ?>
						</div>	
					<?php endif ?>	
				</div> 
			<?php endif ?>	
		<?php
		$output = ob_get_contents();
		ob_end_clean();
		wp_reset_postdata();
		return $output;
	}
}
add_shortcode('tvlgiao_wpdance_title', 'tvlgiao_wpdance_title_function');
?>