<?php
/**
 * The Template for displaying all single posts.
 *
 * @package Wordpress
 */
?>
<?php get_header('none'); ?>
<?php
	$class_id_config 	= tvlgiao_wpdance_get_custom_layout(get_the_ID());
?>
<div id="main-content" class="main-content">
	<div class="container">
		<div class="wd-single-post-wrap wd-main-content">
			<?php while ( have_posts() ) : the_post();  ?>
				<div class="wd-content-header row <?php echo esc_attr( $class_id_config['custom_class'] ); ?>" id="<?php echo esc_attr( $class_id_config['custom_id'] ); ?>">
					<?php the_content(); ?>
				</div>
			<?php endwhile; // End of the loop. ?>
		</div>
	</div>
</div><!-- END CONTAINER  -->
<?php get_footer('none'); ?>