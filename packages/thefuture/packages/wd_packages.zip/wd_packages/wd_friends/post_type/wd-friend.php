<?php
function wd_friend_day_register(){
	register_taxonomy( 'wd_friend_category', array( 'wd_friend' ), array(
		'hierarchical'      	=> true,
		'labels'           		 => array(
			'menu_name'         => esc_html__('Categories Friend' , 'wd_package' ),
			'name' 				=> esc_html__('Categories Friend', 'wd_package'),
			'singular_name' 	=> esc_html__('Categories Friend', 'wd_package'),
			'search_items'      => esc_html__( 'Search Friend', 'wd_package' ),
    		'all_items'         => esc_html__( 'All Friend', 'wd_package' ),            	
        	'new_item'          => esc_html__('Add New', 'wd_package' ),
        	'edit_item'         => esc_html__('Edit Post', 'wd_package' ),
        	'view_item'   		=> esc_html__('View Post', 'wd_package' ),
        	'add_new_item'      => esc_html__('Add New Category Friend', 'wd_package' ),
			'new_item_name'     => esc_html__( 'New Friend Name', 'wd_package' ),
		),
		'show_ui'           	=> true,
		'show_admin_column' 	=> true,
		'query_var'         	=> true,
		'rewrite'           	=> array( 'slug' => 'wd_friend_category' ),				
		'public'				=> true,
	));
	register_post_type('wd_friend', array(
		'labels' => array(
                'name' 					=> _x('WD Friends Say', 'post type general name','wd_package'),
                'singular_name' 		=> _x('WD Friends Say', 'post type singular name','wd_package'),
                'add_new' 				=> _x('Add Friend','wd_package'),
                'add_new_item' 			=> __('Add Friend','wd_package'),
                'edit_item'				=> __('Edit Friend','wd_package'),
                'new_item' 				=> __('New Friend','wd_package'),
                'view_item' 			=> __('View Friend','wd_package'),
                'search_items' 			=> __('Search Friend','wd_package'),
                'not_found' 			=>  __('No Friend found','wd_package'),
                'not_found_in_trash' 	=> __('No Friend found in Trash','wd_package'),
                'parent_item_colon' 	=> '',
                'menu_name' 			=> __('Friends Say','wd_package'),
		),
		'singular_label' 		=> __('Friend','wd_package'),
		'public' 				=> false,
		'publicly_queryable' 	=> true,
		'exclude_from_search' 	=> true,
		'show_ui' 				=> true,
		'show_in_menu' 			=> true,
		'capability_type' 		=> 'page',
		'hierarchical' 			=> false,
		'supports' 			 	=>  array('title','thumbnail','excerpt'),
		'has_archive' 			=> false,
		'rewrite' 				=>  array('slug'  =>  'wd_friend', 'with_front' =>  true),
		'query_var' 			=> false,
		'can_export' 			=> true,
		'show_in_nav_menus' 	=> false,
		'menu_position'			=> 23,
	));
	
}
add_action('init','wd_friend_day_register', 0);
?>