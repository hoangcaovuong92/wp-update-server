<?php
function register_event(){
	register_post_type('event', array(
		'labels' => array(
            'name' 				=> _x('WD Events', 'post type general name','wd_package'),
            'singular_name' 	=> _x('WD Events', 'post type singular name','wd_package'),
            'add_new' 			=> _x('Add Event', 'Event','wd_package'),
            'add_new_item' 		=> __('Add Event','wd_package'),
            'edit_item' 		=> __('Edit Event','wd_package'),
            'new_item' 			=> __('New Event','wd_package'),
            'view_item' 		=> __('View Event','wd_package'),
            'search_items' 		=> __('Search Event','wd_package'),
            'not_found' 		=>  __('No Event found','wd_package'),
            'not_found_in_trash' => __('No Event found in Trash','wd_package'),
            'parent_item_colon' => '',
            'menu_name' 		=> __('Events','wd_package'),
		),
		'singular_label' 		=> __('Event','wd_package'),
		'public' 				=> false,
		'publicly_queryable' 	=> true,
		'exclude_from_search' 	=> true,
		'show_ui' 				=> true,
		'show_in_menu' 			=> true,
		'capability_type' 		=> 'page',
		'hierarchical' 			=> false,
		'supports'  			=>  array('title','custom-fields','editor','thumbnail'),
		'has_archive' 			=> false,
		'rewrite' 				=>  array('slug'  =>  'event', 'with_front' =>  true),
		'query_var' 			=> false,
		'can_export' 			=> true,
		'show_in_nav_menus' 	=> false,
		'menu_position'			=> 23,
	));	
}
add_action('init','register_event');
?>