<?php
/**
 * Custom Walker
 *
 * @access      public
 * @since       1.0 
 * @return      void
 */
class wd_custom_menu_walker extends Walker_Nav_Menu {
    function start_el(&$output, $item, $depth = 0, $args = array(), $id = 0){
        global $wp_query;
        $has_children   = $args->walker->has_children;
        $has_parent     = $item->menu_item_parent ? true : false;

        $indent = ($depth) ? str_repeat("\t", $depth) : ''; 
         
        $li_class_names = $value = '';
        
        $classes            = empty($item->classes) ? array() : (array) $item->classes;
        
        $li_class_names     = join(' ', apply_filters('nav_menu_css_class', array_filter($classes), $item));
        $li_class_names     .= ($item->text_align) ? ' '.$item->text_align : ''; //text align
        $li_class_names     .= ($item->submenu_width && $has_parent) ? ' wd-menu-item-submenu-width-'.str_replace('/', '-', $item->submenu_width) : ''; //Submenu width
        $li_class_names     .= ' wd-menu-item-depth-'.$depth; //menu depth
        //$li_class_names     .= ($has_children) ? ' dropdown' : '';
        $li_class_names     = ' class="' . esc_attr($li_class_names) . '"';

        //background color
        $li_attributes      = !empty($item->bg_color) ? ' style="background-color:' . esc_attr($item->bg_color) . ';"' : '';
        
        $output             .= $indent . '<li id="menu-item-' . $item->ID . '"' . $value . $li_class_names . $li_attributes. '>';
        
        $link_attributes    = !empty($item->attr_title) ? ' title="' . esc_attr($item->attr_title) . '"' : '';
        $link_attributes    .= !empty($item->target) ? ' target="' . esc_attr($item->target) . '"' : '';
        $link_attributes    .= !empty($item->xfn) ? ' rel="' . esc_attr($item->xfn) . '"' : '';
        $link_attributes    .= !empty($item->url) ? ' href="' . esc_attr($item->url) . '"' : '';

        //text color
        $link_attributes    .= !empty($item->text_color) && $has_parent ? ' style="color:' . esc_attr($item->text_color) . ';"' : ''; //children item
        $title_attributes    = !empty($item->text_color) && !$has_parent ? ' style="color:' . esc_attr($item->text_color) . ';"' : ''; //parrent item
        
        $prepend     = '<h3 class="wd-menu-item-title" '.$title_attributes.'>';
        $append      = '</h3>';
        $description = !empty($item->description) ? '<span class="wd-menu-item-desc">' . esc_attr($item->description) . '</span>' : '';
        
        //Flag label
        $flag_label_text     = '';
        if ($item->flag_label == 'new') {
             $flag_label_text = __( 'NEW', 'wd_package' );
        }elseif ($item->flag_label == 'sale') {
             $flag_label_text = __( 'SALE', 'wd_package' );
        }elseif ($item->flag_label == 'hot') {
             $flag_label_text = __( 'HOT', 'wd_package' );
        }
        $flag_label = ($flag_label_text != '') ? '<span class="wd-menu-item-flag wd-menu-item-flag-style-'.$item->flag_label.'">' . esc_html($flag_label_text) . '</span>' : '';

        if ($depth != 0) {
            $description = $append = $prepend = "";
        }
        
        //icon
        $icon = !empty($item->icon_class) ? '<span class="'.$item->icon_class.'"></span>' : '';

        //Hide text title
        $item->title = (!$item->hide_title) ? $icon.' '.$item->title : $icon;

        //Custom Content
        $custom_content_class   = 'wd-submenu-custom-content-wrap';
        $custom_content_class   .= ($item->submenu_custom_content_effect == 'hover') ? ' hidden' : '';
        $custom_content         = '<div class="'.$custom_content_class.'">';
        ob_start();
        if ($item->submenu_content_source == 'widget-area' && $item->submenu_content_widget) {
            if (is_active_sidebar($item->submenu_content_widget) ) {
                dynamic_sidebar( $item->submenu_content_widget );
            }
        }elseif ($item->submenu_content_source == 'shortcode-template' && $item->submenu_content_shortocde_template){
            echo apply_filters('the_content', get_post_field('post_content', $item->submenu_content_shortocde_template));
        }elseif ($item->submenu_content_source == 'custom-shortcode' && $item->submenu_content_custom_shortcode){
            echo do_shortcode( $item->submenu_content_custom_shortcode );
        }
        $custom_content .= ob_get_clean();
        $custom_content .= '</div>';

        $item_output = $args->before;
        $item_output .= '<a' . $link_attributes . '>';
        $item_output .= $args->link_before . $prepend . apply_filters('the_title', $item->title, $item->ID) . $append;
        $item_output .= $description . $args->link_after;
        $item_output .= ($item->submenu_custom_content_effect == 'hover') ? ' ' . $item->subtitle .$custom_content. '</a>' : ' ' . $item->subtitle . '</a>';
        $item_output .= $flag_label;
        $item_output .= $args->after;
        $item_output .= ($item->submenu_custom_content_effect == 'normal') ? $custom_content : '';

        //setting for submenu
        $args->megamenu                             = $item->megamenu;
        $args->columns                              = $item->columns;
        $args->submenu_bg_source                    = $item->submenu_bg_source;
        $args->submenu_bg_color                     = $item->submenu_bg_color;
        $args->submenu_bg_image                     = $item->submenu_bg_image;

        $output .= apply_filters('walker_nav_menu_start_el', $item_output, $item, $depth, $args);
    }


    public function start_lvl( &$output, $depth = 0, $args = array() ) {
        if ( isset( $args->item_spacing ) && 'discard' === $args->item_spacing ) {
            $t = '';
            $n = '';
        } else {
            $t = "\t";
            $n = "\n";
        }
        $indent = str_repeat( $t, $depth );
 
        // Default class.
        $classes = array( 'wd-sub-menu' );
 
        /**
         * Filters the CSS class(es) applied to a menu list element.
         *
         * @since 4.8.0
         *
         * @param array    $classes The CSS classes that are applied to the menu `<ul>` element.
         * @param stdClass $args    An object of `wp_nav_menu()` arguments.
         * @param int      $depth   Depth of menu item. Used for padding.
         */
        $class_names = join( ' ', apply_filters( 'nav_menu_submenu_css_class', $classes, $args, $depth ) );
        $class_names .= ($args->megamenu == '1') ? ' wd-submenu-enable-megamenu' : ' wd-submenu-disabled-megamenu'; //submenu megamenu
        $class_names .= ($args->columns) ? ' wd-submenu-columns-'.$args->columns : ''; //submenu columns
        $class_names .= ' wd-submenu-depth-'.$depth; //menu depth
        $class_names = $class_names ? ' class="' . esc_attr( $class_names ) . '"' : '';
        $attributes  = '';

        //Bg image / bg color
        if ($args->submenu_bg_source == 'bg_image' && $args->submenu_bg_image) {
            $attributes  .= ' style="background-image: url('.esc_url(wp_get_attachment_image_src( $args->submenu_bg_image, 'full' )[0]).'); background-size: cover;"';
        }elseif ($args->submenu_bg_source == 'bg_color' && $args->submenu_bg_color) {
            $attributes  .= ' style="background-color:' . esc_attr($args->submenu_bg_color) . ';"';
        }
 
        $output .= "{$n}{$indent}<ul$class_names $attributes>{$n}";
    }

    public function end_lvl( &$output, $depth = 0, $args = array() ) {
        if ( isset( $args->item_spacing ) && 'discard' === $args->item_spacing ) {
            $t = '';
            $n = '';
        } else {
            $t = "\t";
            $n = "\n";
        }
        $indent = str_repeat( $t, $depth );
        $output .= "$indent</ul>{$n}";
    }

    public function end_el( &$output, $item, $depth = 0, $args = array() ) {
        if ( isset( $args->item_spacing ) && 'discard' === $args->item_spacing ) {
            $t = '';
            $n = '';
        } else {
            $t = "\t";
            $n = "\n";
        }
        $output .= "</li>{$n}";
    }
}