<?php
if (!class_exists('WD_Megamenu')) {
	class WD_Megamenu {
		/**
		 * Refers to a single instance of this class.
		 */
		private static $instance = null;

		public static function get_instance() {
			if ( null == self::$instance ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		protected $post_type 	= 'wd_megamenu';
		protected $taxonomy 	= '';
		protected $arrShortcodes = array('megamenu');

		public function __construct(){
			$this->constant();
			
			/****************************/
			// Register testimonials post type
			add_action('init', array($this, 'register_post_type'));

			//Change Placeholder Title Post
			add_filter( 'enter_title_here', array($this, 'change_title_text' ));
			
			add_action('admin_enqueue_scripts',array($this,'init_admin_script'));

			//Include Lybrary
			add_action('template_redirect', array($this,'template_redirect') );

			//Register Widget Area
			add_action('widgets_init', array($this, 'register_widget_area'), 999);
			
			$this->init_handle(); 

			//Visual Composer
			$this->initShortcodes();
			if($this->checkPluginVC()){
				if ( ! defined( 'ABSPATH' ) ) { exit; }
				add_action("vc_after_init",array($this,'initVisualComposer'));
			}
		}
		
		protected function constant(){
			define('WDMM_BASE'		,   plugin_dir_path( __FILE__ )		);
			define('WDMM_BASE_URI'	,   plugins_url( '', __FILE__ )		);
			define('WDMM_JS'		, 	WDMM_BASE_URI . '/assets/js'	);
			define('WDMM_CSS'		, 	WDMM_BASE_URI . '/assets/css'	);
			define('WDMM_ADMIN_JS'	, 	WDMM_BASE_URI . '/admin/js'		);
			define('WDMM_ADMIN_CSS'	, 	WDMM_BASE_URI . '/admin/css'	);
			define('WDMM_ADMIN_LIB'	, 	WDMM_BASE_URI . '/admin/libs'	);
			define('WDMM_IMAGE'		, 	WDMM_BASE_URI . '/images'		);
			define('WDMM_TEMPLATE' 	, 	WDMM_BASE . '/templates'		);
			define('WDMM_CLASS' 	, 	WDMM_BASE . '/class'			);
			define('WDMM_INCLUDES'	, 	WDMM_BASE . '/includes'			);
		}

		/******************************** testimonials POST TYPE ***********************************/
		public function register_post_type(){
			if (!post_type_exists($this->post_type)) {
				register_post_type($this->post_type, array(
					'exclude_from_search' 	=> true, 
					'labels' 				=> array(
		                'name' 				=> _x('WD Megamenu', 'post type general name','wd_package'),
		                'singular_name' 	=> _x('WD Megamenu', 'post type singular name','wd_package'),
		                'add_new' 			=> _x('Add Megamenu', 'Megamenu','wd_package'),
		                'add_new_item' 			=> sprintf( __( 'Add New %s', 'wd_package' ), __( 'Megamenu', 'wd_package' ) ),
						'edit_item' 			=> sprintf( __( 'Edit %s', 'wd_package' ), __( 'Megamenu', 'wd_package' ) ),
						'new_item' 				=> sprintf( __( 'New %s', 'wd_package' ), __( 'Megamenu', 'wd_package' ) ),
						'all_items' 			=> sprintf( __( 'All %s', 'wd_package' ), __( 'Megamenus', 'wd_package' ) ),
						'view_item' 			=> sprintf( __( 'View %s', 'wd_package' ), __( 'Megamenu', 'wd_package' ) ),
						'search_items' 			=> sprintf( __( 'Search %a', 'wd_package' ), __( 'Megamenu', 'wd_package' ) ),
						'not_found' 			=>  sprintf( __( 'No %s Found', 'wd_package' ), __( 'Megamenu', 'wd_package' ) ),
						'not_found_in_trash' 	=> sprintf( __( 'No %s Found In Trash', 'wd_package' ), __( 'Megamenu', 'wd_package' ) ),
		                'parent_item_colon' => '',
		                'menu_name' 		=> __('WD Megamenu','wd_package'),
					),
					'singular_label' 		=> __('WD Megamenu','wd_package'),
					'public' 				=> true,
					'has_archive' 			=> false,
					'supports' 			 	=>  array(),
					'has_archive' 			=> false,
					'rewrite' 				=>  array('slug'  =>  $this->post_type, 'with_front' =>  true),
					'show_in_nav_menus' 	=> false,
					'menu_icon'				=> 'dashicons-list-view',
					'menu_position'			=> 58,
				));	
			}
		}
		/******************************** testimonials POST TYPE INIT START ***********************************/

		public function change_title_text( $title ){
		    $screen = get_current_screen();
		  
		    if  ( $this->post_type == $screen->post_type ) {
		        $title = esc_html__("Enter megamenu name here", 'wd_package' );
		    }
		    return $title;
		}

		public function template_redirect(){
			global $wp_query,$post,$page_datas,$data;
			if( $wp_query->is_page() || $wp_query->is_single() ){
				if ( has_shortcode( $post->post_content, 'tvlgiao_wpdance_megamenu' ) ) { 
					add_action('wp_enqueue_scripts',array($this,'init_script'));
				}
			}
		}
	
		protected function initShortcodes(){
			foreach($this->arrShortcodes as $shortcode){
				if( file_exists(WDMM_TEMPLATE."/wd_{$shortcode}.php") ){
					require_once WDMM_TEMPLATE."/wd_{$shortcode}.php";
				}	
			}
		}

		public function initVisualComposer(){ 
			foreach ($this->arrShortcodes as $visual) {
				if( file_exists(WDMM_TEMPLATE."/wd_vc_{$visual}.php") ){
					require_once WDMM_TEMPLATE."/wd_vc_{$visual}.php";
				}
			}
	    }

	    protected function init_handle(){
	    	if( file_exists(WDMM_CLASS."/class-wd-megamenu.php") ){
				require_once WDMM_CLASS."/class-wd-megamenu.php";
			}	
			if( file_exists(WDMM_CLASS . "/class-walker.php") ){
				require_once WDMM_CLASS . "/class-walker.php";
			}
			if( file_exists(WDMM_CLASS . "/class-edit-custom-walker.php") ){
				require_once WDMM_CLASS . "/class-edit-custom-walker.php";
			}
			//add_image_size('wd-pricing_table-thumb',400,400,true);  
		}	
		
		public function init_admin_script($hook) {
			$screen = get_current_screen();
			if ($hook = 'nav-menus.php' || $this->post_type == $screen->post_type) {
				wp_enqueue_style('wd-megamenu-admin-custom-css'		, 	WDMM_ADMIN_CSS.'/wd_admin.css');
				wp_enqueue_script('wd-megamenu-admin-custom-scripts',	WDMM_ADMIN_JS.'/wd_script.js',false,false,true);
			}
			
		}
		
		public function init_script(){
			wp_enqueue_style('wd-megamenu-custom-css'		, WDMM_CSS.'/wd_style.css');	
			wp_enqueue_script('wd-megamenu-custom-scripts'	, WDMM_JS.'/wd_script.js',false,false,true);
		}

		//Register Widget Area
		public function register_widget_area(){
				register_sidebar(array(
			        'name' 				=> esc_html__('WD - Megamenu Widget 1', 'wd_package'),
			        'id' 				=> 'wd_megamenu_widget_1',
			        'description'   	=> esc_html__( '', 'wd_package' ),
			        'before_widget' 	=> '<aside id="%1$s" class="widget %2$s">',
			        'after_widget' 		=> '</aside>',
			        'before_title' 		=> '<h2 class="widget-title">',
			        'after_title' 		=> '</h2>',
			    ));
			    register_sidebar(array(
			        'name' 				=> esc_html__('WD - Megamenu Widget 2', 'wd_package'),
			        'id' 				=> 'wd_megamenu_widget_2',
			        'description'   	=> esc_html__( '', 'wd_package' ),
			        'before_widget' 	=> '<aside id="%1$s" class="widget %2$s">',
			        'after_widget' 		=> '</aside>',
			        'before_title' 		=> '<h2 class="widget-title">',
			        'after_title' 		=> '</h2>',
			    ));
			    register_sidebar(array(
			        'name' 				=> esc_html__('WD - Megamenu Widget 3', 'wd_package'),
			        'id' 				=> 'wd_megamenu_widget_3',
			        'description'   	=> esc_html__( '', 'wd_package' ),
			        'before_widget' 	=> '<aside id="%1$s" class="widget %2$s">',
			        'after_widget' 		=> '</aside>',
			        'before_title' 		=> '<h2 class="widget-title">',
			        'after_title' 		=> '</h2>',
			    ));
			    register_sidebar(array(
			        'name' 				=> esc_html__('WD - Megamenu Widget 4', 'wd_package'),
			        'id' 				=> 'wd_megamenu_widget_4',
			        'description'   	=> esc_html__( '', 'wd_package' ),
			        'before_widget' 	=> '<aside id="%1$s" class="widget %2$s">',
			        'after_widget' 		=> '</aside>',
			        'before_title' 		=> '<h2 class="widget-title">',
			        'after_title' 		=> '</h2>',
			    ));
			    register_sidebar(array(
			        'name' 				=> esc_html__('WD - Megamenu Widget 5', 'wd_package'),
			        'id' 				=> 'wd_megamenu_widget_5',
			        'description'   	=> esc_html__( '', 'wd_package' ),
			        'before_widget' 	=> '<aside id="%1$s" class="widget %2$s">',
			        'after_widget' 		=> '</aside>',
			        'before_title' 		=> '<h2 class="widget-title">',
			        'after_title' 		=> '</h2>',
			    ));
			}

		/******************************** Check Visual Composer active ***********************************/
		protected function checkPluginVC(){
			$_active_vc = apply_filters('active_plugins',get_option('active_plugins'));
			if(in_array('js_composer/js_composer.php',$_active_vc)){
				return true;
			}else{
				return false;
			}
		}

	}
	WD_Megamenu::get_instance();  // Start an instance of the plugin class 
}