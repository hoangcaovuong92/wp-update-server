<?php
if( class_exists('WD_Megamenu') ){
	$integrate_specific_menu = tvlgiao_wpdance_vc_get_list_category('nav_menu', false);
	$menu_theme_location     = tvlgiao_wpdance_get_list_menu_registed();
	vc_map(array(
		'name' 				=> esc_html__("WD - Megamenu", 'wd_package'),
		'base' 				=> 'tvlgiao_wpdance_megamenu',
		'description' 		=> esc_html__("Display megamenu by special menu or menu id...", 'wd_package'),
		'category' 			=> esc_html__("WPDance Shortcode", 'wd_package'),
		'icon'        		=> 'vc_icon-vc-gitem-post-categories',
		'params' => array(
			array(
				'type' 			=> 'dropdown',
				'heading' 		=> esc_html__( 'Layout', 'wd_package' ),
				'param_name' 	=> 'layout',
				'admin_label' 	=> true,
				'value' 		=> array(
					'Menu Horizontal'			=> 'menu-horizontal',
					'Menu Vertical'				=> 'menu-vertical',
				),
			),
			array(
				'type' 				=> 'dropdown',
				'heading' 			=> esc_html__( 'Style', 'wd_package' ),
				'param_name' 		=> 'style',
				'admin_label' 		=> true,
				'value' 			=> tvlgiao_wpdance_get_list_style_class(4),
				'description' 		=> '',
				'edit_field_class' 	=> 'vc_col-sm-6',
			),
			array(
				'type' 				=> 'dropdown',
				'heading' 			=> esc_html__( 'Hover Style', 'wd_package' ),
				'param_name' 		=> 'hover_style',
				'admin_label' 		=> true,
				'value' 			=> tvlgiao_wpdance_get_list_style_class(5),
				'description' 		=> '',
				'edit_field_class' 	=> 'vc_col-sm-6',
			),
			array(
				'type' 			=> 'dropdown',
				'heading' 		=> esc_html__( 'Type', 'wd_package' ),
				'param_name' 	=> 'type',
				'admin_label' 	=> true,
				'value' 		=> array(
					'Menu Theme Location'				=> 'theme-location',
					'Integrate Specific Menu'			=> 'specific-menu',
				),
			),
			array(
				'type' 			=> 'dropdown',
				'heading' 		=> esc_html__( 'Menu Theme Location', 'wd_package' ),
				'param_name' 	=> 'menu_theme_location',
				'admin_label' 	=> true,
				'value' 		=> $menu_theme_location,
				'dependency'  	=> Array('element' => "type", 'value' => array('theme-location'))
			),
			array(
				'type' 			=> 'dropdown',
				'heading' 		=> esc_html__( 'Integrate Specific Menu', 'wd_package' ),
				'param_name' 	=> 'integrate_specific_menu',
				'admin_label' 	=> true,
				'value' 		=> $integrate_specific_menu,
				'dependency'  	=> Array('element' => "type", 'value' => array('specific-menu'))
			),
			array(
				'type' 			=> 'textfield',
				'class' 		=> '',
				'heading' 		=> esc_html__("Extra class name", 'wd_package'),
				'description'	=> esc_html__("Style particular content element differently - add a class name and refer to it in custom CSS.", 'wd_package'),
				'admin_label' 	=> true,
				'param_name' 	=> 'class',
				'value' 		=> ''
			)
		)
	));
}
?>