<?php
/**
 * Shortcode: tvlgiao_wpdance_megamenu
 */
if (!function_exists('tvlgiao_wpdance_megamenu_function')) {
	function tvlgiao_wpdance_megamenu_function($atts) {
		extract(shortcode_atts(array(
			'layout'					=> 'menu-horizontal',
			'style'						=> 'style-1',
			'hover_style'				=> 'style-1',
			'layout'					=> 'menu-horizontal',
			'type'						=> 'theme-location',
			'menu_theme_location'		=> '',
			'integrate_specific_menu'	=> '',
			'class' 					=> '',
		), $atts));
		
		ob_start();
		$class_style				= 'wd-megamenu-layout-'.$layout;
		$class_style				.= ' wd-megamenu-'.$style;
		$class_style				.= ' wd-megamenu-hover-'.$hover_style;
		$args 						= array();
		if ($type == 'theme-location') {
			$args['theme_location'] = $menu_theme_location;
		}else{
			$args['menu'] 			= $integrate_specific_menu;
		}
		if (class_exists('wd_custom_menu_walker')) {
			$args['walker'] 			= new wd_custom_menu_walker();
		} ?>
		<div class="wd-shortcode-megamenu <?php echo esc_attr($class_style) ?> <?php echo esc_attr($class) ?>">
			<?php wp_nav_menu($args); ?>
		</div>
		<?php
		$content = ob_get_clean();
		wp_reset_query();
		return $content;
	}
}
add_shortcode('tvlgiao_wpdance_megamenu', 'tvlgiao_wpdance_megamenu_function');
?>