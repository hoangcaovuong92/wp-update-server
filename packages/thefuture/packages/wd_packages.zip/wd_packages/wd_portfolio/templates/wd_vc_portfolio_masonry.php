<?php
# Visual Composer installed?
if ( function_exists( 'visual_composer' ) && ! function_exists( 'wd_vc_shortcodes_portfolio_masonry' ) ) {
	/**
	 * Add theme's custom shortcodes to Visual Composer
	 */
	function wd_vc_shortcodes_portfolio_masonry() {
		vc_map( array(
			'name'        => __( 'WD - Portfolio Masonry', 'wd_package' ),
			'base'        => 'tvlgiao_wpdance_portfolio_masonry',
			'description' => __( 'Style masonry of portfolio', 'wd_package' ),
			'category'    => esc_html__("WPDance Shortcode", 'wd_package'),
			'icon'        => 'vc_icon-vc-masonry-grid',
			'params'      => array(
				array(
					'type'        => 'dropdown',
					'heading'     => __( 'Categories', 'wd_package' ),
					'description' => __( 'Select the category. If you want get category by ID', 'wd_package' ),
					'param_name'  => 'id_category',
					'admin_label' => true,
					'value'       => WD_Portfolio::wd_portfolio_list_categories(),
				),
				array(
					'type'        => 'dropdown',
					'heading'     => __( 'Style', 'wd_package' ),
					'param_name'  => 'style',
					'admin_label' => true,
					'value'       => array(
						__( 'Style 1', 'wd_package' ) => 'portfolio-style-1',
						__( 'Style 2', 'wd_package' ) => 'portfolio-style-2',
					),
					'description' => '',
				),
				array(
					'type'        => 'textfield',
					'class'       => '',
					'heading'     => __( 'Number Portfolio', 'wd_package' ),
					'description' => __( 'number', 'wd_package' ),
					'admin_label' => true,
					'param_name'  => 'number',
					'value'       => '6',
				),
				array(
					'type'        => 'dropdown',
					'heading'     => __( 'Sort By', 'wd_package' ),
					'param_name'  => 'sort',
					'admin_label' => true,
					'value'       => array(
						__( 'Date', 'wd_package' ) => 'date',
						__( 'Name', 'wd_package' ) => 'name',
						__( 'Slug', 'wd_package' ) => 'slug',
					),
					'description' => '',
				),
				array(
					'type'        => 'dropdown',
					'heading'     => __( 'Order By', 'wd_package' ),
					'param_name'  => 'order_by',
					'admin_label' => true,
					'value'       => array(
						'DESC' => 'DESC',
						'ASC'  => 'ASC',
					),
					'description' => '',
				),
				array(
					'type'        => 'dropdown',
					'heading'     => __( 'Layout Mode', 'wd_package' ),
					'param_name'  => 'layout_mode',
					'admin_label' => true,
					'value'       => array(
						__( 'Masonry', 'wd_package' ) => 'masonry',
						__( 'Packery', 'wd_package' ) => 'packery',
					),
					'description' => '',
				),
				array(
					'type'        => 'dropdown',
					'heading'     => __( 'Random Width Image', 'wd_package' ),
					'param_name'  => 'random_width',
					'admin_label' => true,
					'value'       => array(
						__( 'Yes', 'wd_package' ) => '1',
						__( 'No', 'wd_package' )  => '0',
					),
					'description' => '',
					'dependency'  => Array( 'element' => 'layout_mode', 'value' => array( 'packery' ) ),
				),
				array(
					'type'        => 'dropdown',
					'heading'     => __( 'Columns', 'wd_package' ),
					'param_name'  => 'columns',
					'admin_label' => true,
					'value'       => array(
						__( '1 Columns', 'wd_package' ) => '1',
						__( '2 Columns', 'wd_package' ) => '2',
						__( '3 Columns', 'wd_package' ) => '3',
						__( '4 Columns', 'wd_package' ) => '4',
						__( '6 Columns', 'wd_package' ) => '6',
					),
					'description' => '',
					'dependency'  => Array(
						'element' => 'layout_mode',
						'value'   => array( 'masonry' ),
					),
				),
				array(
					"type" 			=> "textfield",
					"class" 		=> "",
					"heading" 		=> esc_html__("Padding", 'wd_package'),
					"param_name" 	=> "gap",
					"value"			=> 0,
					"description" 	=> esc_html__('Padding between images. Only fill in whole numbers or real numbers. Example: 2.5 (Unit: pixels)', 'wd_package'),
				),
				array(
					'type'        => 'dropdown',
					'heading'     => __( 'Show Pagination Or Load More', 'wd_package' ),
					'param_name'  => 'pagination_loadmore',
					'admin_label' => true,
					'value'       => array(
						__( 'Load More', 'wd_package' )  => '0',
						__( 'Pagination', 'wd_package' ) => '1',
						__( 'No Show', 'wd_package' )    => '2',
					),
					'description' => '',
				),
				array(
					'type'        => 'textfield',
					'class'       => '',
					'heading'     => __( 'Number Post Load More', 'wd_package' ),
					'admin_label' => true,
					'param_name'  => 'number_loadmore',
					'value'       => '6',
					'description' => '',
					'dependency'  => Array( 'element' => 'pagination_loadmore', 'value' => array( '0' ) ),
				),
				array(
					'type'        => 'textfield',
					'class'       => '',
					'heading'     => __( 'Extra class name', 'wd_package' ),
					'description' => __( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'wd_package' ),
					'admin_label' => true,
					'param_name'  => 'class',
					'value'       => '',
				),
			),
		) );
	}
}

# add theme's custom shortcodes to Visual Composer
add_action( 'vc_before_init', 'wd_vc_shortcodes_portfolio_masonry' );
