<?php 
add_action( 'wp_ajax_load_more_portfolio_grid', 'wd_load_more_portfolio_grid' );
add_action( 'wp_ajax_nopriv_load_more_portfolio_grid', 'wd_load_more_portfolio_grid' );

if( !function_exists('wd_load_more_portfolio_grid') ){
	function wd_load_more_portfolio_grid() {
		$id_category    = isset( $_REQUEST['id_category'] ) ? $_REQUEST['id_category'] : '';
		$style    		= isset( $_REQUEST['style'] ) ? $_REQUEST['style'] : '';
		$image_size    	= isset( $_REQUEST['image_size'] ) ? $_REQUEST['image_size'] : '';
		$order_by    	= isset( $_REQUEST['order_by'] ) ? $_REQUEST['order_by'] : '';
		$sort   		= isset( $_REQUEST['sort'] ) ? $_REQUEST['sort'] : '';
		$padding    	= isset( $_REQUEST['padding'] ) ? $_REQUEST['padding'] : '';
		$number_loadmore  = isset( $_REQUEST['number_loadmore'] ) ? $_REQUEST['number_loadmore'] : '';
		$offset    		= isset( $_REQUEST['offset'] ) ? $_REQUEST['offset'] : '';
		$random_id    	= isset( $_REQUEST['random_id'] ) ? $_REQUEST['random_id'] : '';

		// New blog
		$args = array(
			'post_type'      	=> 'portfolio',
			'posts_per_page' 	=> $number_loadmore,
			'offset'         	=> $offset,
			'orderby'        	=> $order_by,
			'order'         	=> $sort,
		);

		//Category
		if ( $id_category != - 1 ) {
			$args['tax_query'] = array(
				array(
					'taxonomy' => 'wd-portfolio-category',
					'terms'    => $id_category,
					'field'    => 'term_id',
					'operator' => 'IN',
				),
			);
		}
		$special_portfolio = new WP_Query( $args );

		ob_start();
		if ( $special_portfolio->have_posts() ):
			while ( $special_portfolio->have_posts() ) : $special_portfolio->the_post();
				include( WDP_BASE . '/templates/partials/portfolio_grid.php' );
			endwhile;
			wp_reset_postdata();
		else:
			echo '0';
		endif;

		echo ob_get_clean();
		wp_die();
	}
}

add_action( 'wp_ajax_nopriv_more_portfolio_masonry_ajax', 'wd_more_portfolio_masonry_ajax');
add_action( 'wp_ajax_more_portfolio_masonry_ajax', 'wd_more_portfolio_masonry_ajax' );
if( !function_exists('wd_more_portfolio_masonry_ajax') ){
	function wd_more_portfolio_masonry_ajax() {
		$offset         = $_POST["offset"];
		$posts_per_page = $_POST["posts_per_page"];
		$columns        = $_POST["columns"];
		$sort        	= $_POST["sort"];
		$order_by       = $_POST["order_by"];
		$image_size     = $_POST["image_size"];
		$style          = $_POST["style"];
		$layout_mode    = $_POST["layout_mode"];
		$random_width   = $_POST["random_width"];
		$tab_rand       = $_POST["tab_rand"];
		$gap       		= $_POST["gap"];

		$args = array(
			'post_type'           => 'portfolio',
			'posts_per_page'      => $posts_per_page,
			'offset'              => $offset,
			'orderby' 			  => $attr['sort'],
			'order'				  => $attr['order_by'],
			'ignore_sticky_posts' => 1,
		);

		$posts = new WP_Query( $args );

		ob_start();
		if ( $posts->have_posts() ):
			while ( $posts->have_posts() ) : $posts->the_post();
				include( WDP_BASE . '/templates/partials/portfolio_masonry.php' );
			endwhile;
			wp_reset_postdata();
		else:
			echo '0';
		endif;

		echo ob_get_clean();
		wp_die();
	}
}
?>