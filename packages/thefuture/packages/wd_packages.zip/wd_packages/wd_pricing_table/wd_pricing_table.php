<?php
if (!class_exists('WD_Pricing_Table')) {
	class WD_Pricing_Table {
		/**
		 * Refers to a single instance of this class.
		 */
		private static $instance = null;

		public static function get_instance() {
			if ( null == self::$instance ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		protected $post_type 	= 'wd_pricing_table';
		protected $taxonomy 	= 'wd_pricing_table_categories';
		protected $arrShortcodes = array('pricing_table');

		public function __construct(){
			$this->constant();
			
			/****************************/
			// Register testimonials post type
			add_action('init', array($this, 'register_post_type'));
			add_action('vc_before_init', array( $this, 'register_taxonomy' ) );
			add_filter('attribute_escape', array($this,'rename_second_menu_name') , 10, 2);
			add_theme_support('post-thumbnails', array($this->post_type) );

			//Change Placeholder Title Post
			add_filter( 'enter_title_here', array($this, 'change_title_text' ));
			
			add_action('admin_enqueue_scripts',array($this,'init_admin_script'));
			
			add_action('add_meta_boxes', array( $this,'create_metabox' ) );	
			add_action('pre_post_update', array($this,'metabox_save_data') , 10, 2);
			add_action('template_redirect', array($this,'template_redirect') );
			
			$this->init_handle();

			//Visual Composer
			$this->initShortcodes();
			if($this->checkPluginVC()){
				if ( ! defined( 'ABSPATH' ) ) { exit; }
				add_action("vc_after_init",array($this,'initVisualComposer'));
			}
		}
		
		protected function constant(){
			define('WDPT_BASE'		,   plugin_dir_path( __FILE__ ));
			define('WDPT_BASE_URI'	,   plugins_url( '', __FILE__ ));
			define('WDPT_JS'		, 	WDPT_BASE_URI . '/assets/js'		);
			define('WDPT_CSS'		, 	WDPT_BASE_URI . '/assets/css'		);
			define('WDPT_ADMIN_JS'	, 	WDPT_BASE_URI . '/admin/js'		);
			define('WDPT_ADMIN_CSS'	, 	WDPT_BASE_URI . '/admin/css'		);
			define('WDPT_ADMIN_LIB'	, 	WDPT_BASE_URI . '/admin/libs'		);
			define('WDPT_IMAGE'		, 	WDPT_BASE_URI . '/images'	);
			define('WDPT_TEMPLATE' 	, 	WDPT_BASE . '/templates'	);
			define('WDPT_INCLUDES'	, 	WDPT_BASE . '/includes'	);
		}

		/******************************** testimonials POST TYPE ***********************************/
		public function register_post_type(){
			if (!post_type_exists($this->post_type)) {
				register_post_type($this->post_type, array(
					'exclude_from_search' 	=> true, 
					'labels' 				=> array(
		                'name' 				=> _x('WD Pricing Table', 'post type general name','wd_package'),
		                'singular_name' 	=> _x('WD Pricing Table', 'post type singular name','wd_package'),
		                'add_new' 			=> _x('Add Pricing Table', 'Pricing Table','wd_package'),
		                'add_new_item' 			=> sprintf( __( 'Add New %s', 'wd_package' ), __( 'Pricing Table', 'wd_package' ) ),
						'edit_item' 			=> sprintf( __( 'Edit %s', 'wd_package' ), __( 'Pricing Table', 'wd_package' ) ),
						'new_item' 				=> sprintf( __( 'New %s', 'wd_package' ), __( 'Pricing Table', 'wd_package' ) ),
						'all_items' 			=> sprintf( __( 'All %s', 'wd_package' ), __( 'Pricing Tables', 'wd_package' ) ),
						'view_item' 			=> sprintf( __( 'View %s', 'wd_package' ), __( 'Pricing Table', 'wd_package' ) ),
						'search_items' 			=> sprintf( __( 'Search %a', 'wd_package' ), __( 'Pricing Tables', 'wd_package' ) ),
						'not_found' 			=>  sprintf( __( 'No %s Found', 'wd_package' ), __( 'Pricing Tables', 'wd_package' ) ),
						'not_found_in_trash' 	=> sprintf( __( 'No %s Found In Trash', 'wd_package' ), __( 'Pricing Tables', 'wd_package' ) ),
		                'parent_item_colon' => '',
		                'menu_name' 		=> __('WD Pricing Table','wd_package'),
					),
					'singular_label' 		=> __('WD Pricing Table','wd_package'),
					'taxonomies' 			=> array($this->taxonomy),
					'public' 				=> true,
					'has_archive' 			=> false,
					'supports' 			 	=>  array('title','custom-fields','editor','thumbnail'),
					'has_archive' 			=> false,
					'rewrite' 				=>  array('slug'  =>  $this->post_type, 'with_front' =>  true),
					'show_in_nav_menus' 	=> false,
					'menu_icon'				=> 'dashicons-archive',
					'menu_position'			=> 58,
				));	
			}
		}

		public function register_taxonomy(){
			register_taxonomy( $this->taxonomy, $this->post_type, array(
				'hierarchical'     		=> true,
				'labels'            	=> array(
					'name' 				=> esc_html__('Categories Pricing Table', 'wd_package'),
					'singular_name' 	=> esc_html__('Category Pricing Table', 'wd_package'),
	            	'new_item'          => esc_html__('Add New', 'wd_package' ),
	            	'edit_item'         => esc_html__('Edit Post', 'wd_package' ),
	            	'view_item'   		=> esc_html__('View Post', 'wd_package' ),
	            	'add_new_item'      => esc_html__('Add New Category Pricing Table', 'wd_package' ),
	            	'menu_name'         => esc_html__( 'Categories Pricing Table' , 'wd_package' ),
				),
				'show_ui'           	=> true,
				'show_admin_column' 	=> true,
				'query_var'         	=> true,
				'rewrite'           	=> array( 'slug' => $this->taxonomy ),				
				'public'				=> true,
			));	
		}

		/******************************** testimonials POST TYPE INIT START ***********************************/

		public function metabox_save_data($post_id) {

			if ( ! isset( $_POST['wd_pricing_table_box_nonce'] ) )
				return $post_id;
			// verify this came from the our screen and with proper authorization,
			// because save_post can be triggered at other times
			if (!wp_verify_nonce($_POST['wd_pricing_table_box_nonce'],'wd_pricing_table_box'))
				return $post->ID;
			if (!current_user_can('edit_post', $post->ID))
				return $post->ID;

			$data = array();
			if (isset($_POST['wd_pricing_table'])) {
				$data['wd_pricing_table'] = $_POST['wd_pricing_table'];
			}
			update_post_meta($post_id,'wd_pricing_table_meta_data', serialize($data));
			
		}

		public function process_meta_data_repeatable_field_after_save($meta_key, $list_meta_name){
			$data 	= array();
			if (isset($_POST[$meta_key])) {
				foreach ($list_meta_name as $name) {
					if (count($_POST[$meta_key][$name]) > 0) {
						foreach ($_POST[$meta_key][$name] as $key => $value) {
							$data[$key][$name] = $value;
						}
					}
				}
				//Remove last item (repeatable field)
				unset($data[count($data)-1]);
			}
			return $data;
		}

		public function get_meta_data_default($field = ''){
			$default = array(
				'wd_pricing_table' 	=> array(
					'price'					=> '$100',
					'price_text'			=> 'From %s Per Months',
					'icon'					=> 'fa fa-heartbeat',
					'enable_flag_label'		=> 'on',
					'url'					=> '#',
				),
			);
			return ($field && isset($default[$field])) ? $default[$field] : $default;
		}

		public function get_meta_data($field = ''){
			$default = $this->get_meta_data_default();
			$meta_data = get_post_meta( get_the_ID(), 'wd_pricing_table_meta_data', true );
			$meta_data = ($meta_data) ? wp_parse_args( unserialize($meta_data), $default ) : array();
			return ($field && isset($meta_data[$field])) ? $meta_data[$field] : $meta_data;
		}	
		
		public function template_redirect(){
			global $wp_query,$post,$page_datas,$data;
			if( $wp_query->is_page() || $wp_query->is_single() ){
				if ( has_shortcode( $post->post_content, 'tvlgiao_wpdance_pricing_table' )) { 
					add_action('wp_enqueue_scripts',array($this,'init_script'));
				}
			}
		}
		
		public function create_metabox() {
			if(post_type_exists($this->post_type)) {
				add_meta_box("wp_cp_pricing_table_info", "Pricing Detail", array($this,"metabox_form"), $this->post_type, "normal", "high");
			}
		}

		public function metabox_form(){
			wp_nonce_field( 'wd_pricing_table_box', 'wd_pricing_table_box_nonce' );
			$random_id 	= 'wd-pricing_table-metabox-'.mt_rand();
			$meta_key 	= 'wd_pricing_table';
			$meta_data 	= $this->get_meta_data($meta_key);
			$meta_data 	= empty($meta_data) ? $this->get_meta_data_default($meta_key) : $meta_data;
			?>
			<table id="<?php echo esc_attr( $random_id ); ?>" class="form-table wd-pricing-table-custom-meta-box wd-custom-meta-box-width">
				<tbody>
					<tr>
						<th scope="row"><label><?php esc_html_e( 'Price', 'wd_package' ); ?>:</label></th>
						<td><input type="text" class="wd-full-width" name="wd_pricing_table[price]" value="<?php echo esc_attr($meta_data['price']);?>"/></td>
					</tr>
					<tr>
						<th scope="row"><label><?php esc_html_e( 'Price Text', 'wd_package' ); ?>:</label></th>
						<td><input type="text" class="wd-full-width" name="wd_pricing_table[price_text]" value="<?php echo esc_attr($meta_data['price_text']);?>" placeholder="Ex: From %s Per Months" />
						<p class="description"><?php echo esc_html__("Use \"%s\" to replace the price.", 'wd_package'); ?></p></td>
					</tr>
					<tr>
						<th scope="row"><label><?php esc_html_e( 'Class Font Icon', 'wd_package' ); ?>:</label></th>
						<td><input type="text" class="wd-full-width" name="wd_pricing_table[icon]" value="<?php echo esc_attr($meta_data['icon']);?>"/>
							<p class="description"><?php echo sprintf(esc_html( 'Enter the class font. Exam: fa fa-heartbeat. view all at %s or %s' , 'wd_package' ), '<a href="http://fontawesome.io/icons/" target="_blank">http://fontawesome.io/icons/</a>', '<a href="https://linearicons.com/free" target="_blank">https://linearicons.com/free</a>') ; ?></p></td> 
					</tr>
					<tr>
						<th scope="row"><label><?php echo esc_html__("Enable Flag Label", 'wd_package'); ?>:</label></th>
						<td>
							<?php 
								$checked 			= !empty($meta_data['enable_flag_label']) && $meta_data['enable_flag_label'] == 'on' ? 'checked="true"' : '';  ?>
							<input type="checkbox" class="" name="wd_pricing_table[enable_flag_label]" <?php echo $checked; ?> />
						</td>
					</tr>
					<tr>
						<th scope="row"><label><?php esc_html_e( 'URL', 'wd_package' ); ?>:</label></th>
						<td><input type="text" class="wd-full-width" name="wd_pricing_table[url]" value="<?php echo esc_attr($meta_data['url']);?>"/></td> 
					</tr>
				</tbody>
			</table>
		<?php
		}

		public function change_title_text( $title ){
		    $screen = get_current_screen();
		  
		    if  ( $this->post_type == $screen->post_type ) {
		        $title = esc_html__("Enter the pricing table name here", 'wd_package' );
		    }
		    return $title;
		}
		
		public function rename_second_menu_name($safe_text, $text) {
			if (__('Pricing Table Items', 'wd_package') !== $text) {
				return $safe_text;
			}

			// We are on the main menu item now. The filter is not needed anymore.
			remove_filter('attribute_escape', array($this,'rename_second_menu_name') );

			return __('WD Pricing Table', 'wd_package');
		}

		protected function initShortcodes(){
			foreach($this->arrShortcodes as $shortcode){
				if( file_exists(WDPT_TEMPLATE."/wd_{$shortcode}.php") ){
					require_once WDPT_TEMPLATE."/wd_{$shortcode}.php";
				}	
			}
		}

		public function initVisualComposer(){ 
			foreach ($this->arrShortcodes as $visual) {
				if( file_exists(WDPT_TEMPLATE."/wd_vc_{$visual}.php") ){
					require_once WDPT_TEMPLATE."/wd_vc_{$visual}.php";
				}
			}
	    }

	    protected function init_handle(){
			//add_image_size('wd-pricing_table-thumb',400,400,true);  
		}	
		
		public function init_admin_script($hook) {
			$screen = get_current_screen();
			if ($hook = 'post.php' && $this->post_type == $screen->post_type) {
				wp_enqueue_style('font-awesome', 						WDPT_ADMIN_LIB.'/font-awesome/css/font-awesome.min.css');
				wp_enqueue_style('wd-testimonials-admin-custom-css', 	WDPT_ADMIN_CSS.'/wd_admin.css');
				wp_enqueue_script( 'wd-testimonials-scripts',		 	WDPT_ADMIN_JS.'/wd_script.js',false,false,true);
			}
			
		}	
		
		
		public function init_script(){
			wp_enqueue_style('wd-pricing_table-custom-css', 	WDPT_CSS.'/wd_custom.css');	
			wp_enqueue_script( 'wd-pricing_table-scripts',	WDPT_JS.'/wd_ajax.js',false,false,true);
		}


		/******************************** Check Visual Composer active ***********************************/
		protected function checkPluginVC(){
			$_active_vc = apply_filters('active_plugins',get_option('active_plugins'));
			if(in_array('js_composer/js_composer.php',$_active_vc)){
				return true;
			}else{
				return false;
			}
		}

	}
	WD_Pricing_Table::get_instance();  // Start an instance of the plugin class 
}