<?php

// **********************************************************************// 
// ! Register New Element: Pricing Table
// **********************************************************************//
if (!function_exists('tvlgiao_wpdance_pricing_table_function')) {
	function tvlgiao_wpdance_pricing_table_function($atts, $content = null) {
      extract(shortcode_atts(array(
            'single_or_multi'           => 'single',
            'id_pricing'                => '',
            'id_category'               => '-1',
            'display'                   => 'columns',
            'columns'                   => '4',
            'columns_tablet'            => 2,
            'columns_mobile'            => 1,
            'number_post'               => '4',
            'sort'                      => 'ASC',
            'order_by'                  => 'date',
            'style'                     => 'style-1',
            'text_align'                => 'text-center',
            'show_icon_font_thumbnail'  => 'hide',
            'image_size'                => 'full',
            'button_text'               => 'BUY NOW',
            'show_label'                => '1',
            'label_style'               => 'style-1',
            'label_text'                => 'HOT',
            'label_bg_color'            => '',
            'label_text_color'          => '',
            'class'                     => '',
            'is_slider'                 => '0',
            'show_nav'                  => '1',
            'auto_play'                 => '1',
            'style_class'               => 'style-1',
        ),$atts));

        $args = array(
            'post_type'             => 'wd_pricing_table',
            'post_status'           => 'publish',
        );
        if ($single_or_multi == 'single' && $id_pricing) {
            $args['post__in'] = array($id_pricing);
        }elseif ($single_or_multi == 'multi') {
            $args['posts_per_page'] = $number_post;
            $args['order']          = $sort;
            $args['orderby']        = $order_by;

            if( $id_category != 0 && $id_category != '-1' ){
                $args['tax_query']= array(
                    array(
                        'taxonomy'      => 'wd_pricing_table_categories',
                        'terms'         => $id_category,
                        'field'         => 'term_id',
                        'operator'      => 'IN'
                    )
                );
            }
        }

        $style_class    = 'wd-pricing-table-'.$style.' wd-pricing-table-display-'.$display;
        $label_class    = 'wd-pricing-table-label-'.$label_style;
        $label_style    = ($label_bg_color != '' || $label_text_color != '') ? 'style="' : '';
        $label_style    .= $label_bg_color != '' ? 'background-color: '.$label_bg_color.';' : '';
        $label_style    .= $label_text_color != '' ? 'color: '.$label_text_color.';' : '';
        $label_style    .= ($label_bg_color != '' || $label_text_color != '') ? '"' : '';
        
        $tab_style      = ($display == 'tab') ? true : false;

        $pricing_table  = new WP_Query($args);

        if ($pricing_table->found_posts <= $columns || $style == 'style-2') {
            $is_slider = '0';
        }
        $columns_class    = ($single_or_multi == 'multi' && !$tab_style) ? 'wd-columns-'.$columns.' wd-tablet-columns-'.$columns_tablet.' wd-mobile-columns-'.$columns_mobile : 'wd-columns-1';
        $columns_class    = ($is_slider == '0') ? $columns_class : '';

        $random_id = 'wd-pricing-table-'.mt_rand();
        ob_start();
        if ( $pricing_table->have_posts() ) { ?>
            <div id="<?php echo esc_attr($random_id); ?>" class="wd-shortcode-pricing-table-wrapper <?php echo esc_attr($columns_class); ?> <?php echo esc_attr($style_class); ?> <?php echo esc_attr($class); ?>">
                <?php $content_html   = array(); $i = 1; ?>
                <?php while( $pricing_table->have_posts() ) { $pricing_table->the_post();
                    global $post;
                    $post_id        = $post->ID;
                    $meta_data      = unserialize(get_post_meta($post_id,'wd_pricing_table_meta_data',true));

                    $thumbnail  = '';
                    if ($show_icon_font_thumbnail == 'show-icon'){
                        $icon_font   = (!empty($meta_data['wd_pricing_table']['icon'])) ? $meta_data['wd_pricing_table']['icon'] : $icon_font;
                        $icon_font   = (!empty($icon_font)) ? $icon_font : 'fa fa-heartbeat';
                        $thumbnail   = '<div class="wd-pricing-table-item-icon"><span class="'. esc_attr($icon_font).'"></span></div>';
                    }elseif ($show_icon_font_thumbnail == 'show-image'){
                        if (has_post_thumbnail() && get_the_post_thumbnail()) {
                            $thumbnail_image =  get_the_post_thumbnail($post_id, $image_size, array( 'alt' => esc_attr(get_the_title()), 'title' => esc_attr(get_the_title()) ) );
                        }else{
                            $thumbnail_image .= '<img src="'.WDPT_IMAGE.'/no-image.jpg" alt="'.esc_attr(get_the_title()).'" title="'.esc_attr(get_the_title()).'"  />';
                        }
                        $thumbnail = ($thumbnail_image) ? '<div class="wd-pricing-table-item-thumbnail">'.$thumbnail_image.'</div>' : '';
                    }

                    $title          = '<h3 class="wd-pricing-table-item-title heading_title">'.get_the_title().'</h3>';
                    $price          = strpos($meta_data['wd_pricing_table']['price_text'], '%s') ? sprintf($meta_data['wd_pricing_table']['price_text'], '<span class="wd-pricing-table-item-price-number">'.$meta_data['wd_pricing_table']['price'].'</span>') : '<span class="wd-pricing-table-item-price-number">'.$meta_data['wd_pricing_table']['price'].'</span>';
                    $label          = ($show_label == '1' && !empty($meta_data['wd_pricing_table']['enable_flag_label']) && $meta_data['wd_pricing_table']['enable_flag_label'] == 'on') ? '<div class="wd-pricing-table-item-label '.esc_attr($label_class).'" '.$label_style.'><span>'.$label_text.'</span></div>' : '';
                    $button         = '<div class="wd-pricing-table-item-button"><a href="'.$meta_data['wd_pricing_table']['url'].'">'.esc_html($button_text).'</a></div>';

                    $header_content = '<div class="wd-pricing-table-item-header">'.$thumbnail.$title.$label.'</div>';
                    $price_content  = '<div class="wd-pricing-table-item-price">'.$price.'</div>';
                    $main_content   = '<div class="wd-pricing-table-item-content">'.get_the_content().'</div>';
                    $footer_content = '<div class="wd-pricing-table-item-footer">'.$button.'</div>';

                    ?>
                   
                    <?php if (!$tab_style): ?>
                        <?php ob_start(); ?>
                        <li class="wd-pricing-table-item">
                            <div class="wd-pricing-table-item-content">
                                <?php echo $header_content; ?>
                                <?php echo $price_content; ?>
                                <?php echo $main_content; ?>
                                <?php echo $footer_content; ?>
                            </div>
                        </li>
                        <?php $content_html[] = ob_get_clean(); ?>
                    <?php else: ?>
                        <?php 
                        $random_id_tab  = 'wd-pricing-table-tab-'.mt_rand().$i;
                        $active_class   = $i == 1 ? 'active' : '';
                        $title_tab      = '<li class="'.$active_class.'"><a  href="#'.$random_id_tab.'" data-toggle="tab">'.$header_content.'</a></li>';
                        $content_tab    = '<div class="tab-pane '.$active_class.'" id="'.$random_id_tab.'">'.$price_content.$main_content.$footer_content.'</div>';
                        $content_html['title_tab'][]      = $title_tab; 
                        $content_html['content_tab'][]    = $content_tab; 
                        ?>
                    <?php endif ?>
                    <?php $i ++; ?>
                <?php } ?> <!-- end while -->


                <?php if (!$tab_style): ?>
                    <ul class="wd-pricing-table-list">
                        <?php foreach ($content_html as $content): ?>
                            <?php echo $content; ?>
                        <?php endforeach ?>
                    </ul>
                <?php else: ?>
                    <ul  class="nav nav-pills">
                        <?php foreach ($content_html['title_tab'] as $content): ?>
                            <?php echo $content; ?>
                        <?php endforeach ?>
                    </ul>

                    <div class="tab-content clearfix">
                        <?php foreach ($content_html['content_tab'] as $content): ?>
                            <?php echo $content; ?>
                        <?php endforeach ?>
                    </div>

                 <?php endif ?>

                <?php if( $show_nav && $is_slider == '1'){ ?>
                    <?php tvlgiao_wpdance_slider_control(); ?>
                <?php } ?>
            </div>
            <?php if ( $is_slider == '1') : ?>
                <script type="text/javascript">
                    jQuery(document).ready(function(){
                        "use strict";                       
                        var $_this = jQuery('#<?php echo esc_attr( $random_id ); ?>');
                        var _auto_play = <?php echo esc_attr( $auto_play ); ?>;
                        var owl = $_this.find('.wd-pricing-table-list').owlCarousel({
                            loop : true,
                            items : <?php echo $columns ?>,
                            nav : false,
                            dots : true,
                            navSpeed : 1000,
                            slideBy: 1,
                            rtl:jQuery('body').hasClass('rtl'),
                            navRewind: false,
                            autoplay: _auto_play,
                            autoplayTimeout: 5000,
                            autoplayHoverPause: true,
                            autoplaySpeed: false,
                            mouseDrag: true,
                            touchDrag: false,
                            responsiveBaseElement: $_this,
                            responsiveRefreshRate: 1000,
                            responsive:{
                                0:{
                                    items : <?php echo $columns_mobile; ?>
                                },
                                426:{
                                    items : <?php echo $columns_tablet; ?>
                                },
                                768:{
                                    items : <?php echo $columns ?>
                                }
                            },
                            onInitialized: function(){
                            }
                        });
                        $_this.on('click', '.next', function(e){
                            e.preventDefault();
                            owl.trigger('next.owl.carousel');
                        });

                        $_this.on('click', '.prev', function(e){
                            e.preventDefault();
                            owl.trigger('prev.owl.carousel');
                        });
                    });
                </script>
            <?php endif; // Endif Slider ?>
            <?php
        }
        $output = ob_get_contents();
        ob_end_clean();
        wp_reset_query();
        return $output; 
	}
}
add_shortcode('tvlgiao_wpdance_pricing_table', 'tvlgiao_wpdance_pricing_table_function');

?>