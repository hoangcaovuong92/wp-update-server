<?php
	$pricing_table_options 		= tvlgiao_wpdance_vc_get_data_by_post_type('wd_pricing_table');
	$pricing_table_cat_options	= tvlgiao_wpdance_vc_get_list_category('wd_pricing_table_categories');
	vc_map( array(
		'name' 				=> esc_html__("WD - Pricing Table", 'wd_package'),
		'base' 				=> 'tvlgiao_wpdance_pricing_table',
		'description' 		=> esc_html__("Pricing Table", 'wd_package'),
		'category' 			=> esc_html__("WPDance Shortcode", 'wd_package'),
		'icon'        		=> 'icon-wpb-call-to-action',
		"params" 			=> array(
			array(
				'type' 				=> 'dropdown',
				'heading' 			=> esc_html__( 'Single Or Multi', 'wd_package' ),
				'param_name' 		=> 'single_or_multi',
				'admin_label' 		=> true,
				'value' 			=> array( 
					'Single'			=> 'single',
					'Multi'				=> 'multi'
				),
			),
			//Single
			array(
				'type' 				=> 'dropdown',
				'heading' 			=> esc_html__( 'Select A Pricing Table', 'wd_package' ),
				'param_name' 		=> 'id_pricing',
				'admin_label' 		=> true,
				'value' 			=> $pricing_table_options,
				'description' 		=> '',
				'dependency'		=> Array('element' => "single_or_multi", 'value' => array('single'))
			),
			//Multi
			array(
				'type' 				=> 'dropdown',
				'heading' 			=> esc_html__( 'Select Pricing Table Category', 'wd_package' ),
				'param_name' 		=> 'id_category',
				'admin_label' 		=> true,
				'value' 			=> $pricing_table_cat_options,
				'description' 		=> '',
				'dependency'		=> Array('element' => "single_or_multi", 'value' => array('multi'))
			),
			array(
				'type' 				=> 'dropdown',
				'heading' 			=> esc_html__( 'Display', 'wd_package' ),
				'param_name' 		=> 'display',
				'admin_label' 		=> true,
				'value' 			=> array( 
					'Columns'			=> 'columns',
					'Tab'				=> 'tab',
				),
				'std'				=> 'hide',
				'description' 		=> '',
				'edit_field_class' 	=> 'vc_col-sm-6',
				'dependency'		=> Array('element' => "single_or_multi", 'value' => array('multi'))
			),
			array(
				'type' 				=> 'dropdown',
				'heading' 			=> esc_html__( 'Columns', 'wd_package' ),
				'param_name' 		=> 'columns',
				'admin_label' 		=> true,
				'value' 			=> tvlgiao_wpdance_vc_get_list_tvgiao_columns(),
				'std'				=> 4,
				'description' 		=> esc_html__( '', 'wd_package' ),
				'edit_field_class' 	=> 'vc_col-sm-6',
				'dependency'		=> Array('element' => "display", 'value' => array('columns'))
			),
			array(
				'type' 				=> 'dropdown',
				'heading' 			=> esc_html__( 'Columns On Tablet', 'wd_package' ),
				'param_name' 		=> 'columns_tablet',
				'admin_label' 		=> true,
				'value' 			=> tvlgiao_wpdance_vc_get_list_columns_tablet(),
				'std'				=> 2,
				'description' 		=> esc_html__( '', 'wd_package' ),
				"group"				=> esc_html__('Responsive', 'wd_package'),
			),
			array(
				'type' 				=> 'dropdown',
				'heading' 			=> esc_html__( 'Columns On Mobile', 'wd_package' ),
				'param_name' 		=> 'columns_mobile',
				'admin_label' 		=> true,
				'value' 			=> tvlgiao_wpdance_vc_get_list_columns_mobile(),
				'std'				=> 1,
				'description' 		=> esc_html__( '', 'wd_package' ),
				"group"				=> esc_html__('Responsive', 'wd_package'),
			),
			array(
				'type'				=> 'textfield',
				'heading' 			=> esc_html__( 'Number Of Pricing Table', 'wd_package' ),
				'param_name' 		=> 'number_post',
				'admin_label' 		=> true,
				'value' 			=> '4',
				'edit_field_class' 	=> 'vc_col-sm-6',
				'dependency'		=> Array('element' => "single_or_multi", 'value' => array('multi'))
			),
			array(
				'type' 				=> 'dropdown',
				'heading' 			=> esc_html__( 'Sort By', 'wd_package' ),
				'param_name' 		=> 'sort',
				'admin_label' 		=> true,
				'value' 			=> tvlgiao_wpdance_get_sort_by_values(),
				'std' 				=> 'ASC',
				'description' 		=> '',
				'edit_field_class' 	=> 'vc_col-sm-6',
				'dependency'		=> Array('element' => "single_or_multi", 'value' => array('multi'))
			),
			array(
				'type' 				=> 'dropdown',
				'heading' 			=> esc_html__( 'Order By', 'wd_package' ),
				'param_name' 		=> 'order_by',
				'admin_label' 		=> true,
				'value' 			=> tvlgiao_wpdance_get_order_by_values(),
				'std' 				=> 'date',
				'description' 		=> '',
				'edit_field_class' 	=> 'vc_col-sm-6',
				'dependency'		=> Array('element' => "single_or_multi", 'value' => array('multi'))
			),
			//Style
			array(
				'type' 				=> 'dropdown',
				'heading' 			=> esc_html__( 'Style', 'wd_package' ),
				'param_name' 		=> 'style',
				'admin_label' 		=> true,
				'value' 			=> tvlgiao_wpdance_get_list_style_class(5),
				'description' 		=> '',
				'edit_field_class' 	=> 'vc_col-sm-6',
			),
			array(
				'type' 				=> 'dropdown',
				'heading' 			=> esc_html__( 'Text Align', 'wd_package' ),
				'param_name' 		=> 'text_align',
				'admin_label' 		=> true,
				'value' 			=> tvlgiao_wpdance_vc_get_list_text_align_bootstrap(),
				'std' 				=> 'text-center',
				'description' 		=> '',
				'edit_field_class' 	=> 'vc_col-sm-6',
			),
			array(
				'type' 				=> 'dropdown',
				'heading' 			=> esc_html__( 'Show Thumbnail Or Icon Font', 'wd_package' ),
				'param_name' 		=> 'show_icon_font_thumbnail',
				'admin_label' 		=> true,
				'value' 			=> array( 
					'Hide Icon & Thumbnail'	=> 'hide',
					'Show Icon Font'		=> 'show-icon',
					'Show Thumbnail'		=> 'show-image',
				),
				'std'				=> 'hide',
				'description' 		=> '',
				'edit_field_class' 	=> 'vc_col-sm-6',
			),
			array(
				'type' 				=> 'dropdown',
				'heading' 			=> esc_html__( 'Thumbnail Size', 'wd_package' ),
				'param_name' 		=> 'image_size',
				'admin_label' 		=> true,
				'value' 			=> tvlgiao_wpdance_vc_get_list_image_size(),
				'description' 		=> '',
				'edit_field_class' 	=> 'vc_col-sm-6',
				'dependency'  		=> Array('element' => "show_icon_font_thumbnail", 'value' => array('show-image'))
			),

			//Button
			array(
				'type' 				=> 'textfield',
				'class' 			=> '',
				'heading' 			=> esc_html__("Button Text", 'wd_package'),
				'description'		=> esc_html__("", 'wd_package'),
				'admin_label' 		=> true,
				'param_name' 		=> 'button_text',
				'value' 			=> 'BUY NOW',
			),
			//Label
			array(
				'type' 				=> 'dropdown',
				'heading' 			=> esc_html__( 'Show Label', 'wd_package' ),
				'param_name' 		=> 'show_label',
				'admin_label' 		=> true,
				'value' 			=> array( 
					'Show'				=> '1',
					'Hide'				=> '0',
				),
				'std'				=> 'show',
				'description' 		=> '',
			),
			array(
				'type' 				=> 'dropdown',
				'heading' 			=> esc_html__( 'Label Style', 'wd_package' ),
				'param_name' 		=> 'label_style',
				'admin_label' 		=> true,
				'value' 			=> tvlgiao_wpdance_get_list_style_class(2),
				'description' 		=> '',
				'edit_field_class' 	=> 'vc_col-sm-6',
				'dependency'  		=> Array('element' => "show_label", 'value' => array('1')),
			),
			array(
				'type' 				=> 'textfield',
				'class' 			=> '',
				'heading' 			=> esc_html__("Label Text", 'wd_package'),
				'description'		=> '',
				'admin_label' 		=> true,
				'param_name' 		=> 'label_text',
				'value' 			=> 'HOT',
				'edit_field_class' 	=> 'vc_col-sm-6',
				'dependency'  		=> Array('element' => "show_label", 'value' => array('1')),
			),
			array(
			  	"type" 				=> "colorpicker",
			  	"class" 			=> "",
			  	"heading" 			=> __( "Label Background Color", 'wd_package' ),
			  	"param_name"		=> "label_bg_color",
			  	"value" 			=> '', 
			  	"description" 		=> __( "Choose button's background color...", 'wd_package' ),
			  	'edit_field_class' 	=> 'vc_col-sm-6',
			  	'dependency'  		=> Array('element' => "show_label", 'value' => array('1')),
			),
			array(
			  	"type" 				=> "colorpicker",
			  	"class" 			=> "",
			  	"heading" 			=> __( "Label Text Color", 'wd_package' ),
			  	"param_name"		=> "label_text_color",
			  	"value" 			=> '', 
			  	"description" 		=> __( "Choose button's text color...", 'wd_package' ),
			  	'edit_field_class' 	=> 'vc_col-sm-6',
			  	'dependency'  		=> Array('element' => "show_label", 'value' => array('1')),
			),
			//Global
			array(
				'type' 				=> 'textfield',
				'class' 			=> '',
				'heading' 			=> esc_html__("Extra class name", 'wd_package'),
				'description'		=> esc_html__("Style particular content element differently - add a class name and refer to it in custom CSS.", 'wd_package'),
				'admin_label' 		=> true,
				'param_name' 		=> 'class',
				'value' 			=> ''
			),
			/*-----------------------------------------------------------------------------------
				SLIDER SETTING
			-------------------------------------------------------------------------------------*/
			array(
				"type" 				=> "dropdown",
				"class" 			=> "",
				"heading" 			=> esc_html__("Is Slider", 'wd_package'),
				"admin_label" 		=> true,
				"param_name" 		=> "is_slider",
				"value" 			=> array(
						'Yes' 		=> '1',
						'No' 		=> '0'
					),
				'std'				=> '0',
				"description" 		=> esc_html__('', 'wd_package'),
				"group"				=> esc_html__('Slider Setting', 'wd_package'),
				'dependency'		=> Array('element' => "display", 'value' => array('columns'))
			),
			array(
				"type" 				=> "dropdown",
				"class" 			=> "",
				"heading" 			=> esc_html__("Show Nav", 'wd_package'),
				"admin_label" 		=> true,
				"param_name" 		=> "show_nav",
				"value" 			=> array(
						'Yes' 		=> '1',
						'No' 		=> '0'
					),
				"description" 		=> "",
				"group"				=> esc_html__('Slider Setting', 'wd_package'),
				'dependency'  		=> Array('element' => "is_slider", 'value' => array('1')),
				'edit_field_class' 	=> 'vc_col-sm-6',
			),
			array(
				"type" 				=> "dropdown",
				"class" 			=> "",
				"heading" 			=> esc_html__("Auto Play", 'wd_package'),
				"admin_label" 		=> true,
				"param_name" 		=> "auto_play",
				"value" 			=> array(
						'Yes' 		=> '1',
						'No' 		=> '0'
					),
				"description" 		=> "",
				"group"				=> esc_html__('Slider Setting', 'wd_package'),
				'dependency'  		=> Array('element' => "is_slider", 'value' => array('1')),
				'edit_field_class' 	=> 'vc_col-sm-6',
			),
			
		)
	));
?>