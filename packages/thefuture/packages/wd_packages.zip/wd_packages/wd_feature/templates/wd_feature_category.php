<?php
/**
 * Shortcode: tvlgiao_wpdance_feature_category
 */
if(!function_exists('tvlgiao_wpdance_feature_category_function')){
	function tvlgiao_wpdance_feature_category_function($atts){
		$atts = shortcode_atts(array(
			'id'						=> 0,
			'columns'					=> 4,
			'columns_tablet'			=> 2,
			'columns_mobile'			=> 1,
			'number_feature'			=> 4,
			'sort'						=> 'ASC',
			'order_by'					=> 'date', 
			'text_align'				=> 'text-left', 
			'show_icon_font_thumbnail'	=> 'show-icon',
			'icon_size'					=> 'fa-1x',
			'style_font'				=> 'sync-with-title',
			'image_size'				=> 'full',
			'title'						=> '1',
			'show_excerpt'				=> '1',
			'number_word'				=> '10',
			'readmore'					=> '1',
			'open_link_with'			=> 'modal',
			'readmore_text'				=> 'Read More',
			'is_slider'					=> '0',
			'show_nav'					=> '1',
			'auto_play'					=> '1',
			'style_class'				=> 'style-1',
			'class'						=> '',
		),$atts);
		$args_item 			= $atts;
		$args_item['type'] 	= 'multi';
		extract($atts);

		$args = array(
			'post_type'				=> 'wpdance_feature',
			'post_status'			=> 'publish',
			'posts_per_page' 		=> $number_feature,
			'order' 				=> $sort,
			'orderby'				=> $order_by,
		);

		if( $id != 0 && $id != '-1' ){
			$args['tax_query']= array(
		    	array(
			    	'taxonomy' 		=> 'wpdance_feature_categories',
					'terms' 		=> $id,
					'field' 		=> 'term_id',
					'operator' 		=> 'IN'
				)
   			);
		}
		$_feature 	= new WP_Query($args);

		if ($_feature->found_posts <= $columns) {
			$is_slider = '0';
		}
		$columns_feature 	= ($is_slider == '0') ? 'wd-columns-'.$columns.' wd-tablet-columns-'.$columns_tablet.' wd-mobile-columns-'.$columns_mobile : '';

		$random_id = 'wd-feature-category-'.mt_rand();
		ob_start();
		if ( $_feature->have_posts() ) { ?>
			<div id="<?php echo esc_attr($random_id); ?>" class="row wd-feature-category-wrapper <?php echo esc_attr($columns_feature); ?> <?php echo esc_attr($class); ?>">
				<ul class="wd-feature-content-list">
					<?php 
					while( $_feature->have_posts() ) { $_feature->the_post();
						echo tvlgiao_wpdance_get_future_content_item($args_item); 
					} ?> <!-- end while -->
				</ul>

				<?php if( $show_nav && $is_slider == '1'){ ?>
					<?php tvlgiao_wpdance_slider_control(); ?>
				<?php } ?>
			</div>
			<?php if ( $is_slider == '1') : ?>
				<script type="text/javascript">
					jQuery(document).ready(function(){
						"use strict";						
						var $_this = jQuery('#<?php echo esc_attr( $random_id ); ?>');
						var _auto_play = <?php echo esc_attr( $auto_play ); ?>;
						var owl = $_this.find('.wd-feature-content-list').owlCarousel({
							loop : true,
							items : <?php echo $columns ?>,
							nav : false,
							dots : true,
							navSpeed : 1000,
							slideBy: 1,
							rtl:jQuery('body').hasClass('rtl'),
							navRewind: false,
							autoplay: _auto_play,
							autoplayTimeout: 5000,
							autoplayHoverPause: true,
							autoplaySpeed: false,
							mouseDrag: true,
							touchDrag: false,
							responsiveBaseElement: $_this,
							responsiveRefreshRate: 1000,
							responsive:{
								0:{
									items : <?php echo $columns_mobile; ?>
								},
								426:{
									items : <?php echo $columns_tablet; ?>
								},
								768:{
									items : <?php echo $columns ?>
								}
							},
							onInitialized: function(){
							}
						});
						$_this.on('click', '.next', function(e){
							e.preventDefault();
							owl.trigger('next.owl.carousel');
						});

						$_this.on('click', '.prev', function(e){
							e.preventDefault();
							owl.trigger('prev.owl.carousel');
						});
					});
				</script>
			<?php endif; // Endif Slider ?>
			<?php
		}
		$output = ob_get_contents();
		ob_end_clean();
		wp_reset_query();
		return $output;
	}
}
add_shortcode('tvlgiao_wpdance_feature_category','tvlgiao_wpdance_feature_category_function');
?>