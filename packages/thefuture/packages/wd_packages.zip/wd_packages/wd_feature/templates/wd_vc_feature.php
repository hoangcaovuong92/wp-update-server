<?php
	$feature_options = tvlgiao_wpdance_vc_get_data_by_post_type('wpdance_feature');
	vc_map( array(
		'name' 			=> esc_html__( 'WD - Feature Single', 'wd_package' ),
		'base' 			=> 'tvlgiao_wpdance_feature',
		'description' 	=> __( "Display detail of single feature...", 'wd_package' ),
		'category' 		=> esc_html__("WPDance Shortcode", 'wd_package'),
		'icon'        	=> 'vc_icon-vc-gitem-post-meta',
		'params' 		=> array(
			array(
				'type' 				=> 'dropdown',
				'heading' 			=> esc_html__( 'Feature ID', 'wd_package' ),
				'param_name' 		=> 'id',
				'admin_label' 		=> true,
				'value' 			=> $feature_options,
				'description' 		=> ''
			),
			array(
				'type' 				=> 'dropdown',
				'heading' 			=> esc_html__( 'Show Thumbnail Or Icon Font', 'wd_package' ),
				'param_name' 		=> 'show_icon_font_thumbnail',
				'admin_label' 		=> true,
				'value' 			=> array( 
					'Show Icon Font'		=> 'show-icon',
					'Show Image/Thumbnail'	=> 'show-image',
					'Hide Icon & Thumbnail'	=> 'hide'
				),
				'description' 		=> ''
			),
			//Show Icon Setting
			array(
				'type' 				=> 'dropdown',
				'heading' 			=> esc_html__( 'Feature Icon Or Custom Icon', 'wd_package' ),
				'param_name' 		=> 'feature_icon_or_custom_icon',
				'admin_label' 		=> true,
				'value' 			=> array( 
					'Feature Icon'		=> 'feature-icon',
					'Custom Icon'		=> 'custom-icon',
				),
				'description' 		=> '',
				'edit_field_class' 	=> 'vc_col-sm-6',
				'dependency'  		=> Array('element' => "show_icon_font_thumbnail", 'value' => array('show-icon'))
			),
			array(
				'type' 				=> 'iconpicker',
				'heading' 			=> esc_html__( 'Icon', 'wd_package' ),
				'param_name' 		=> 'icon_fontawesome',
				'value' 			=> 'fa fa-adjust',
				'settings' 			=> array(
					'emptyIcon' 		=> false,
					'iconsPerPage' 		=> 4000,
				),
				'description' 		=> esc_html__( 'Select icon from library.', 'wd_package' ),
				'edit_field_class' 	=> 'vc_col-sm-6',
				'dependency'  		=> Array('element' => "feature_icon_or_custom_icon", 'value' => array('custom-icon'))
			),
			array(
				'type' 				=> 'dropdown',
				'heading' 			=> esc_html__( 'Icon Size', 'wd_package' ),
				'param_name' 		=> 'icon_size',
				'admin_label' 		=> true,
				"value" 			=> tvlgiao_wpdance_vc_get_list_awesome_font_size(),
				"std" 				=> "fa-1x",
				'description' 		=> '',
				'edit_field_class' 	=> 'vc_col-sm-6',
				'dependency'		=> Array('element' => "show_icon_font_thumbnail", 'value' => array('show-icon'))
			),
			array(
				'type' 				=> 'dropdown',
				'heading' 			=> esc_html__( 'Style Font Icon', 'wd_package' ),
				'param_name' 		=> 'style_font',
				'admin_label' 		=> true,
				'value' 			=> array(
						'Sync with title'			=> 'sync-with-title',
						'Separate from title'		=> 'separate-from-title'
					),
				'description' 		=> '',
				'dependency'		=> Array('element' => "show_icon_font_thumbnail", 'value' => array('show-icon'))
			),
			//Show Image/thumbnail Setting
			array(
				'type' 				=> 'dropdown',
				'heading' 			=> esc_html__( 'Image Or Thumbnail', 'wd_package' ),
				'param_name' 		=> 'image_or_thumbnail',
				'admin_label' 		=> true,
				'value' 			=> array( 
					'Show Thumbnail'		=> 'feature-thumbnail',
					'Show Custom Image'		=> 'custom-image',
				),
				'description' 		=> '',
				'edit_field_class' 	=> 'vc_col-sm-6',
				'dependency'  		=> Array('element' => "show_icon_font_thumbnail", 'value' => array('show-image'))
			),
			array(
				"type" 				=> "attach_image",
				"class" 			=> "",
				"heading" 			=> esc_html__("Select Image", 'wd_package'),
				"param_name" 		=> "custom_image",
				"value" 			=> "",
				'edit_field_class' 	=> 'vc_col-sm-6',
				"description" 		=> esc_html__('', 'wd_package'),
				'dependency'  		=> Array('element' => "image_or_thumbnail", 'value' => array('custom-image'))
			),
			array(
				'type' 				=> 'dropdown',
				'heading' 			=> esc_html__( 'Thumbnail Size', 'wd_package' ),
				'param_name' 		=> 'image_size',
				'admin_label' 		=> true,
				'value' 			=> tvlgiao_wpdance_vc_get_list_image_size(),
				'description' 		=> '',
				'edit_field_class' 	=> 'vc_col-sm-6',
				'dependency'  		=> Array('element' => "show_icon_font_thumbnail", 'value' => array('show-image'))
			),
			//Global Setting
			array(
				'type' 				=> 'dropdown',
				'heading' 			=> esc_html__( 'Text Align', 'wd_package' ),
				'param_name' 		=> 'text_align',
				'admin_label' 		=> true,
				'value' 			=> tvlgiao_wpdance_vc_get_list_text_align_bootstrap(),
				'std' 				=> 'text-left',
				'description' 		=> '',
				'edit_field_class' 	=> 'vc_col-sm-6',
			),
			array(
				'type' 				=> 'dropdown',
				'heading' 			=> esc_html__( 'Show feature title', 'wd_package' ),
				'param_name' 		=> 'title',
				'admin_label' 		=> true,
				'value' 			=> array(
						'Yes'	=> '1',
						'No'	=> '0'
					),
				'description' 		=> '',
				'edit_field_class' 	=> 'vc_col-sm-6',
			),
			array(
				'type' 				=> 'dropdown',
				'heading' 			=> esc_html__( 'Show excerpt', 'wd_package' ),
				'param_name' 		=> 'show_excerpt',
				'admin_label' 		=> true,
				'value' 			=> array(
						'Yes'	=> '1',
						'No'	=> '0'
					),
				'description' 		=> '',
				'edit_field_class' 	=> 'vc_col-sm-6',
			),
			array(
				'type' 				=> 'textfield',
				'class' 			=> '',
				'heading' 			=> esc_html__("Number Word Excerpt", 'wd_package'),
				'description'		=> esc_html__("Set -1 to show full excerpt", 'wd_package'),
				'admin_label' 		=> true,
				'param_name' 		=> 'number_word',
				'value' 			=> '10',
				'edit_field_class' 	=> 'vc_col-sm-6',
				'dependency'		=> Array('element' => "excerpt", 'value' => array('1'))
			),
			array(
				'type' 				=> 'dropdown',
				'heading' 			=> esc_html__( 'Show Readmore', 'wd_package' ),
				'param_name' 		=> 'readmore',
				'admin_label' 		=> true,
				'value' 			=> array(
						'No'	=> '0',
						'Yes'	=> '1'
						
					),
				'description' 		=> '',
				'edit_field_class' 	=> 'vc_col-sm-6',
			),
			array(
				'type' 				=> 'dropdown',
				'heading' 			=> esc_html__( 'Open Link With', 'wd_package' ),
				'param_name' 		=> 'open_link_with',
				'admin_label' 		=> true,
				'value' 			=> array(
						'Modal Popup'	=> 'modal',
						'Feature Link'	=> 'link'
					),
				'std' 				=> 'modal',
				'description' 		=> '',
				'edit_field_class' 	=> 'vc_col-sm-6',
				'dependency'  		=> Array('element' => "readmore", 'value' => array('1')),
			),
			array(
				'type' 				=> 'textfield',
				'class' 			=> '',
				'heading' 			=> esc_html__("Readmore Text", 'wd_package'),
				'description'		=> esc_html__("Leave blank if you want to use single feature read more text setting.", 'wd_package'),
				'admin_label' 		=> true,
				'param_name' 		=> 'readmore_text',
				'value' 			=> 'Read More',
				'dependency'  		=> Array('element' => "readmore", 'value' => array('1')),
			),
			array(
				'type' 				=> 'dropdown',
				'heading' 			=> esc_html__( 'Style', 'wd_package' ),
				'param_name' 		=> 'style_class',
				'admin_label' 		=> true,
				'value' 			=> tvlgiao_wpdance_get_list_style_class(11),
				'description' 		=> '',
			),
			array(
				'type' 				=> 'textfield',
				'class' 			=> '',
				'heading' 			=> esc_html__("Extra class name", 'wd_package'),
				'description'		=> esc_html__("Style particular content element differently - add a class name and refer to it in custom CSS.", 'wd_package'),
				'admin_label' 		=> true,
				'param_name' 		=> 'class',
				'value' 			=> ''
			),
		)
	));
?>